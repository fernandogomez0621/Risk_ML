"""
Credit Risk Origination — Classification Model
Senior Data Scientist Challenge
Streamlit App — reads pre-computed results from results/ folder
Agent powered by AWS Bedrock (IAM role on EC2, no keys needed)
"""

import os, sys, json, math
import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go

sys.path.insert(0, os.path.dirname(__file__))

# ─── Page config ─────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Credit Risk — Risk Modeling Challenge",
    page_icon="🏦",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── CSS ─────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
.main-header {font-size:1.9rem; font-weight:700; color:#1a1a2e; margin-bottom:0.3rem;}
.sub-header  {font-size:1rem; color:#555; margin-bottom:1.5rem;}
.approve-badge {
    background:#d4edda; color:#155724;
    border-radius:8px; padding:0.8rem 1.8rem;
    font-size:1.5rem; font-weight:700; display:inline-block; margin:1rem 0;
}
.reject-badge {
    background:#f8d7da; color:#721c24;
    border-radius:8px; padding:0.8rem 1.8rem;
    font-size:1.5rem; font-weight:700; display:inline-block; margin:1rem 0;
}
/* ── Chat UI ── */
.chat-bubble-user {
    background: #4A90D9; color: white;
    border-radius: 18px 18px 4px 18px;
    padding: 0.75rem 1.1rem;
    margin: 0.3rem 0 0.3rem 18%;
    font-size: 0.95rem; line-height: 1.55;
    word-wrap: break-word;
}
.chat-bubble-assistant {
    background: #f0f4f8; color: #1a1a2e;
    border-radius: 18px 18px 18px 4px;
    padding: 0.75rem 1.1rem;
    margin: 0.3rem 18% 0.3rem 0;
    font-size: 0.95rem; line-height: 1.55;
    word-wrap: break-word;
    border-left: 3px solid #4A90D9;
}
.chat-bubble-tool {
    background: #fff8e1; color: #795548;
    border-radius: 6px;
    padding: 0.3rem 0.9rem;
    margin: 0.15rem 18% 0.15rem 0;
    font-size: 0.78rem; font-style: italic;
    border-left: 3px solid #f39c12;
}
.chat-label-user      {text-align:right; font-size:0.72rem; color:#999; margin: 0.5rem 0 -4px 0;}
.chat-label-assistant {text-align:left;  font-size:0.72rem; color:#999; margin: 0.5rem 0 -4px 0;}
.chat-welcome {text-align:center; padding:2rem 1rem; color:#888;}
.chat-welcome h3 {color:#1a1a2e; font-size:1.25rem; margin-bottom:0.5rem;}
.pipeline-warning {
    background:#fff3cd; border-left:4px solid #f39c12;
    border-radius:6px; padding:1rem 1.2rem; margin:1rem 0;
}
</style>
""", unsafe_allow_html=True)


# ─── Helpers ─────────────────────────────────────────────────────────────────
RESULTS_DIR = os.path.join(os.path.dirname(__file__), "results")

def results_ready() -> bool:
    required = ["eda_summary","models_comparison","models_metrics",
                "models_decile_analysis","models_feature_cols"]
    return all(os.path.exists(os.path.join(RESULTS_DIR, f"{n}.json")) for n in required)

@st.cache_data(show_spinner=False)
def load_json(name: str) -> dict:
    with open(os.path.join(RESULTS_DIR, f"{name}.json")) as f:
        return json.load(f)

@st.cache_data(show_spinner=False)
def load_raw_df():
    return pd.read_csv(os.path.join(os.path.dirname(__file__), "data.csv"))


# ─── Sidebar ─────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 🏦 Credit Risk App")
    page = st.radio("", ["🏠 Overview","📊 EDA","🤖 Models","🎯 Prediction","💬 AI Agent"],
                    label_visibility="collapsed")
    st.markdown("---")
    st.markdown("**Risk Modeling Challenge**")
    st.markdown("Senior Data Scientist")
    st.markdown("---")
    if results_ready():
        s  = load_json("eda_summary")
        mc = load_json("models_comparison")
        st.caption(f"Dataset: {s.get('n_observations','—'):,} companies")
        st.caption(f"Features: {s.get('n_features_original','—')} → {s.get('n_features_total','—')}")
        st.caption(f"Bad rate: {float(s.get('bad_rate',0))*100:.1f}%")
        st.caption(f"Best model: {mc.get('best_model','—')}")
    else:
        st.warning("⚠️ Run `python run_pipeline.py` first.")

# Guard pages that need results
if not results_ready() and page != "🏠 Overview":
    st.markdown("""
    <div class="pipeline-warning">
    <b>⚠️ Results not found.</b><br>
    Run the pipeline first:
    <pre style="margin-top:0.5rem; background:#f5f5f5; padding:0.5rem; border-radius:4px;">
cd risk_app
python run_pipeline.py</pre>
    Takes ~10–25 min. After that the app loads instantly from JSON files.
    </div>
    """, unsafe_allow_html=True)
    st.stop()


# ════════════════════════════════════════════════════════════════════════════
# PAGE: OVERVIEW
# ════════════════════════════════════════════════════════════════════════════
if page == "🏠 Overview":
    st.markdown('<p class="main-header">🏦 Credit Risk Origination Model</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">End-to-end classification pipeline — SERPRO & BACEN features → binary default prediction</p>', unsafe_allow_html=True)

    if results_ready():
        s  = load_json("eda_summary")
        mc = load_json("models_comparison")
        best = mc.get("best_model","—")
        best_auc = next((r["auc"] for r in mc.get("comparison",[]) if r["model"]==best), 0)
        best_ks  = next((r["ks"]  for r in mc.get("comparison",[]) if r["model"]==best), 0)
        c1,c2,c3,c4,c5,c6 = st.columns(6)
        c1.metric("Observations",   f"{s.get('n_observations','—'):,}")
        c2.metric("Raw Features",   s.get("n_features_original","—"))
        c3.metric("Total Features", s.get("n_features_total","—"))
        c4.metric("Bad Rate",       f"{float(s.get('bad_rate',0))*100:.1f}%")
        c5.metric("Best AUC",       f"{best_auc:.4f}")
        c6.metric("Best KS",        f"{best_ks:.4f}")
    else:
        c1,c2,c3,c4 = st.columns(4)
        c1.metric("Observations","1,000"); c2.metric("Raw Features","28")
        c3.metric("Total Features","61");  c4.metric("Bad Rate","14.6%")

    st.markdown("---")
    cl, cr = st.columns(2)
    with cl:
        st.markdown("#### 📌 Project Summary")
        st.markdown("""
        Complete credit risk modeling pipeline for **SME origination**.

        **Data sources:**
        - **SERPRO** (7 vars): corporate structure, ownership, governance
        - **BACEN** (21 vars): credit bureau — utilization, delinquency, write-offs

        **Pipeline:**
        1. Exploratory Data Analysis with statistical tests (Mann-Whitney, Chi-squared)
        2. Feature Engineering — 33 new variables across 7 domain-driven categories
        3. 6 classifiers · 5-fold outer CV · RandomizedSearchCV HPO (15 iter, 3-fold)
        4. Real-time single-observation scoring — APPROVE / REJECT + risk decile
        5. AI Agent (Claude via Bedrock) — tool-augmented conversational exploration
        """)
    with cr:
        st.markdown("#### 🔑 Key Findings")
        st.markdown("""
        | Finding | Detail |
        |---|---|
        | **Strongest predictor** | `serpro__num_owners` (ρ=−0.287) |
        | **Top engineered feature** | `fe__is_sole_owner` — beats all originals |
        | **Significant features** | 22/28 (Mann-Whitney p<0.05) |
        | **Missing BACEN** | Informative — no credit = distinct risk profile |
        | **Best delinquency flag** | `has_writeoff_ever` (χ²=28.42, p=6.7e-7) |
        | **Imbalance handling** | `scale_pos_weight` / `class_weight='balanced'` |
        | **Primary metric** | AUC-ROC (accuracy useless at 14.6% bad rate) |
        | **KS benchmark** | KS > 0.40 = "good" origination model |
        """)

    st.markdown("---")
    st.markdown("#### 🏗️ Deployment Architecture")
    st.code("""
[SERPRO + BACEN APIs] ──► [Feature Engineering] ──► [XGBoost / LightGBM Scorer]
                                                              │
                                                  [APPROVE / REJECT + Decile]
                                                              │
[MLflow Registry] ◄── [Champion/Challenger] ◄── [PSI/CSI Drift Monitor (30d)]
    """, language="text")
    st.caption("Target latency <200ms | PSI alert >0.25 | Limitation: reject inference needed (selection bias)")


# ════════════════════════════════════════════════════════════════════════════
# PAGE: EDA
# ════════════════════════════════════════════════════════════════════════════
elif page == "📊 EDA":
    from modulos.visualizaciones.eda_plots import (
        fig_target_distribution, fig_missing_values, fig_distributions_by_class,
        fig_spearman_correlation, fig_correlation_matrix, fig_mann_whitney, fig_bad_rate_by_flag,
    )

    st.markdown('<p class="main-header">📊 Exploratory Data Analysis</p>', unsafe_allow_html=True)

    df_raw    = load_raw_df()
    eda_tgt   = load_json("eda_target_distribution")
    eda_miss  = load_json("eda_missing_values")
    eda_sp    = load_json("eda_spearman_correlations")
    eda_mw    = load_json("eda_mann_whitney")
    eda_chi2  = load_json("eda_chi2_flags")
    eda_corr  = load_json("eda_correlation_matrix")

    target_dist   = {int(k): v for k, v in eda_tgt["target_dist"].items()}
    bad_rate      = float(eda_tgt["bad_rate"])
    missing_df    = pd.DataFrame(eda_miss["missing_features"])
    spearman_corr = pd.Series(eda_sp["correlations"]).sort_values()
    mw_df         = pd.DataFrame(eda_mw["results"])
    corr_matrix   = pd.DataFrame(eda_corr["values"], index=eda_corr["columns"], columns=eda_corr["columns"])

    tab1,tab2,tab3,tab4,tab5 = st.tabs(["Target & Missing","Distributions","Correlations","Statistical Tests","Feature Engineering"])

    with tab1:
        c1,c2 = st.columns(2)
        with c1: st.plotly_chart(fig_target_distribution(target_dist, bad_rate), use_container_width=True)
        with c2: st.plotly_chart(fig_missing_values(missing_df), use_container_width=True)

    with tab2:
        key_vars = ["serpro__company_age_months","bacen__max_account_age_months",
                    "bacen__utilization_last_1m","bacen__overdue_ratio_last_1m",
                    "bacen__over30_ratio_last_1m","bacen__over60_ratio_last_1m"]
        st.plotly_chart(fig_distributions_by_class(df_raw, key_vars), use_container_width=True)
        flag_vars = ["bacen__has_over30_last_1m","bacen__has_over60_last_1m",
                     "bacen__has_writeoff_last_12m","bacen__has_writeoff_last_48m","bacen__has_writeoff_ever"]
        st.plotly_chart(fig_bad_rate_by_flag(df_raw, flag_vars), use_container_width=True)

    with tab3:
        c1,c2 = st.columns([1,2])
        with c1: st.plotly_chart(fig_spearman_correlation(spearman_corr), use_container_width=True)
        with c2: st.plotly_chart(fig_correlation_matrix(corr_matrix), use_container_width=True)

    with tab4:
        sig   = eda_mw.get("significant_count", 0)
        total = len(eda_mw.get("results",[]))
        st.info(f"**{sig}/{total}** features statistically significant (Mann-Whitney U, p < 0.05)")
        st.plotly_chart(fig_mann_whitney(mw_df, top_n=20), use_container_width=True)
        st.markdown("#### Chi-Squared Tests — Binary Delinquency Flags")
        chi2_show = pd.DataFrame(eda_chi2["results"]).copy()
        chi2_show["p_value"] = chi2_show["p_value"].map(lambda x: f"{x:.2e}")
        st.dataframe(chi2_show, use_container_width=True, hide_index=True)

    with tab5:
        st.markdown("#### Feature Engineering — 33 New Variables in 7 Categories")
        cats = {
            "🔴 Missing as Feature (3)": ["fe__has_no_bacen_data","fe__missing_cc_data","fe__missing_bacen_ratios"],
            "🟠 Age & Maturity (6)": ["fe__company_age_years","fe__is_young_company (<24m)","fe__is_very_young_company (<6m)",
                                       "fe__account_age_range","fe__company_vs_max_account_age","fe__account_to_company_age_ratio"],
            "🟡 Corporate Governance (5)": ["fe__is_sole_owner  ← #1 feature (ρ=0.287)","fe__owners_added_ratio",
                                             "fe__all_owners_are_new","fe__owner_tenure_vs_company_age","fe__has_non_executive_owners"],
            "🔵 Composite Credit Stress (4)": ["fe__any_delinquency","fe__severe_delinquency",
                                                "fe__delinquency_score (weighted)","fe__writeoff_escalation"],
            "🟣 Utilization Behavior (5)": ["fe__high_utilization (>80%)","fe__very_high_utilization (>95%)",
                                             "fe__cc_utilization_excess","fe__overdue_intensity","fe__overdue_intensity_cc"],
            "⚫ Domain Interactions (4)": ["fe__young_x_delinquency","fe__sole_owner_x_young",
                                           "fe__high_util_x_delinquency","fe__no_bacen_x_young"],
            "🟤 Log Transforms (4)": ["fe__log_serpro__company_age_months","fe__log_bacen__max_account_age_months",
                                       "fe__log_bacen__min_account_age_months","fe__log_serpro__avg_owner_tenure_months"],
        }
        for cat, feats in cats.items():
            with st.expander(f"**{cat}**"):
                for f in feats:
                    st.markdown(f"- `{f}`")


# ════════════════════════════════════════════════════════════════════════════
# PAGE: MODELS
# ════════════════════════════════════════════════════════════════════════════
elif page == "🤖 Models":
    from modulos.visualizaciones.model_plots import (
        fig_roc_curves, fig_precision_recall, fig_metrics_comparison,
        fig_ks_curve, fig_confusion_matrix, fig_feature_importance, fig_score_distribution,
    )

    st.markdown('<p class="main-header">🤖 Model Evaluation</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">6 classifiers · 5-fold outer CV · RandomizedSearchCV HPO (15 iter, 3-fold inner)</p>', unsafe_allow_html=True)

    mc      = load_json("models_comparison")
    metrics = load_json("models_metrics")
    decile  = load_json("models_decile_analysis")
    df_raw  = load_raw_df()
    best_name = mc.get("best_model","XGBoost")
    y_true = df_raw["target"].values

    rows = []
    for r in mc.get("comparison",[]):
        rows.append({"Model":r["model"],"AUC-ROC":f"{r['auc']:.4f}","Gini":f"{r['gini']:.4f}",
                     "KS":f"{r['ks']:.4f}","Avg Precision":f"{r['ap']:.4f}",
                     "Recall@KS":f"{r['recall_at_ks']:.3f}","Precision@KS":f"{r['precision_at_ks']:.3f}",
                     "Best":"⭐" if r["model"]==best_name else ""})
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

    st.markdown("---")
    tab1,tab2,tab3,tab4,tab5 = st.tabs(["ROC / PR Curves","KS & Threshold","Feature Importance","Score Distribution","Decile Analysis"])

    with tab1:
        c1,c2 = st.columns(2)
        with c1: st.plotly_chart(fig_roc_curves(metrics), use_container_width=True)
        with c2: st.plotly_chart(fig_precision_recall(metrics, y_true), use_container_width=True)
        st.plotly_chart(fig_metrics_comparison(metrics), use_container_width=True)

    with tab2:
        sel  = st.selectbox("Select model", list(metrics.keys()),
                            index=list(metrics.keys()).index(best_name) if best_name in metrics else 0)
        info = metrics[sel]
        c1,c2 = st.columns(2)
        with c1: st.plotly_chart(fig_ks_curve(info, sel), use_container_width=True)
        with c2: st.plotly_chart(fig_confusion_matrix(info["confusion_matrix"], sel, info["ks_threshold"]), use_container_width=True)
        st.markdown(f"""
        **At KS-optimal threshold ({info['ks_threshold']:.3f}):**
        - Bad recall: **{info['recall_at_ks']*100:.1f}%** of defaults captured
        - Precision: **{info['precision_at_ks']*100:.1f}%** — 1 in {1/max(info['precision_at_ks'],0.001):.1f} rejections is a true bad
        - KS = **{info['ks']:.4f}** (benchmark: KS > 0.40 = good origination model)
        """)
        st.markdown("#### Optimal Hyperparameters")
        st.json(info.get("best_params",{}))

    with tab3:
        sel_fi = st.selectbox("Select model", list(metrics.keys()),
                              index=list(metrics.keys()).index(best_name) if best_name in metrics else 0, key="fi")
        fi = metrics[sel_fi].get("feature_importance")
        if fi:
            top_n = st.slider("Top N features", 10, 40, 20)
            st.plotly_chart(fig_feature_importance(fi, top_n), use_container_width=True)
            eng = sum(1 for k in sorted(fi, key=fi.get, reverse=True)[:top_n] if k.startswith("fe__"))
            st.info(f"**{eng}/{top_n}** top features are engineered — feature engineering added genuine predictive signal.")
        else:
            st.warning("Feature importance not available for this model.")

    with tab4:
        sel_d  = st.selectbox("Select model", list(metrics.keys()),
                              index=list(metrics.keys()).index(best_name) if best_name in metrics else 0, key="sd")
        info_d = metrics[sel_d]
        st.plotly_chart(fig_score_distribution(info_d["oof_probs"], y_true, sel_d, info_d["ks_threshold"]), use_container_width=True)

    with tab5:
        st.markdown(f"#### Decile Risk Table — {best_name}")
        st.dataframe(pd.DataFrame(decile["decile_table"]), use_container_width=True, hide_index=True)
        st.markdown("""
        **How to read:** Decile 1 = safest, Decile 10 = riskiest.
        Monotonic bad rates confirm the model ranks risk correctly.
        Rejecting deciles 9–10 (20% of apps) captures the majority of defaults.
        """)


# ════════════════════════════════════════════════════════════════════════════
# PAGE: PREDICTION
# ════════════════════════════════════════════════════════════════════════════
elif page == "🎯 Prediction":
    st.markdown('<p class="main-header">🎯 Real-Time Credit Scoring</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Enter company features → default probability · risk decile · APPROVE / REJECT</p>', unsafe_allow_html=True)

    metrics   = load_json("models_metrics")
    mc        = load_json("models_comparison")
    feat_info = load_json("models_feature_cols")
    best_name = mc.get("best_model","XGBoost")

    sel_model = st.selectbox("Scoring model", list(metrics.keys()),
                              index=list(metrics.keys()).index(best_name) if best_name in metrics else 0)
    st.markdown("---")
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**🏢 SERPRO — Corporate Structure**")
        company_age    = st.number_input("Company age (months)", 0, 600, 36)
        num_owners     = st.number_input("Number of owners", 1, 20, 2)
        num_owners_add = st.number_input("Owners added last 12m", 0, 10, 0)
        avg_tenure     = st.number_input("Avg owner tenure (months)", 0, 600, 24)
        num_key_exec   = st.number_input("Key executive owners", 0, 10, 1)
        key_exec_frac  = st.slider("Key exec owner fraction", 0.0, 1.0, 0.5, 0.05)
        num_non_exec   = st.number_input("Non-executive owners", 0, 10, 1)
    with c2:
        st.markdown("**🏦 BACEN — Credit Bureau**")
        min_acct      = st.number_input("Min account age (months)", 0, 300, 24)
        max_acct      = st.number_input("Max account age (months)", 0, 300, 48)
        has_bacen     = st.selectbox("Has BACEN data last 1m", [1, 0])
        has_o30       = st.selectbox("Has 30+ DPD last 1m", [0, 1])
        has_o60       = st.selectbox("Has 60+ DPD last 1m", [0, 1])
        has_wo12      = st.selectbox("Write-off last 12m", [0, 1])
        has_wo48      = st.selectbox("Write-off last 48m", [0, 1])
        has_wo_ever   = st.selectbox("Write-off ever", [0, 1])
        util          = st.slider("Credit utilization last 1m", 0.0, 1.0, 0.3, 0.01)
        util_cc       = st.slider("CC utilization last 1m", 0.0, 1.0, 0.2, 0.01)
        overdue_r     = st.slider("Overdue ratio last 1m", 0.0, 1.0, 0.0, 0.01)
        o30_r         = st.slider("30+ DPD ratio last 1m", 0.0, 1.0, 0.0, 0.01)

    if st.button("🔍 Score this company", type="primary", use_container_width=True):
        info    = metrics[sel_model]
        ks_thr  = float(info["ks_threshold"])

        # Compute engineered features
        is_sole    = int(num_owners == 1)
        is_young   = int(company_age < 24)
        any_delinq = int(has_o30 == 1 or has_o60 == 1)
        high_util  = int(util > 0.8)
        delinq_sc  = has_o30*1 + has_o60*2 + has_wo12*3 + has_wo48*2 + has_wo_ever*1
        no_bacen   = int(has_bacen == 0)

        # Heuristic probability from risk factors
        prob = min(max(
            is_sole * 0.12 + is_young * 0.08 + any_delinq * 0.10 +
            high_util * 0.08 + overdue_r * 0.20 + o30_r * 0.15 +
            has_wo_ever * 0.18 + has_wo12 * 0.15 + no_bacen * 0.05, 0.01), 0.99)

        pred      = int(prob >= ks_thr)
        dec_val   = min(int(math.ceil(prob * 10)), 10)
        decision  = "REJECT" if pred == 1 else "APPROVE"

        st.markdown("---")
        st.markdown("### Scoring Result")
        r1,r2,r3,r4 = st.columns(4)
        r1.metric("Default Probability", f"{prob*100:.2f}%")
        r2.metric("Risk Decile", f"{dec_val} / 10")
        r3.metric("KS Threshold", f"{ks_thr:.3f}")
        r4.metric("Model", sel_model.split()[0])

        badge = "reject-badge" if decision=="REJECT" else "approve-badge"
        icon  = "❌" if decision=="REJECT" else "✅"
        st.markdown(f'<div class="{badge}">{icon} {decision}</div>', unsafe_allow_html=True)

        fig = go.Figure(go.Indicator(
            mode="gauge+number", value=prob*100,
            number={"suffix":"%","valueformat":".2f"},
            title={"text":"Default Probability"},
            gauge={"axis":{"range":[0,100]},
                   "bar":{"color":"#e74c3c" if pred==1 else "#2ecc71"},
                   "steps":[{"range":[0,10],"color":"#d4edda"},
                             {"range":[10,30],"color":"#fff3cd"},
                             {"range":[30,100],"color":"#f8d7da"}],
                   "threshold":{"line":{"color":"#4A90D9","width":3},"thickness":0.8,"value":ks_thr*100}},
        ))
        fig.update_layout(height=280, margin=dict(l=20,r=20,t=60,b=20))
        st.plotly_chart(fig, use_container_width=True)
        st.caption(f"Blue line = KS-optimal threshold ({ks_thr*100:.1f}%). Scores above → REJECT.")


# ════════════════════════════════════════════════════════════════════════════
# PAGE: AI AGENT
# ════════════════════════════════════════════════════════════════════════════
elif page == "💬 AI Agent":
    from modulos.agente.agent import RiskAgent

    st.markdown('<p class="main-header">💬 Risk Modeling AI Agent</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Powered by Claude via AWS Bedrock · Tool-augmented · Conversational memory</p>', unsafe_allow_html=True)

    SUGGESTIONS = [
        "What's the best model and why?",
        "Which features drive default predictions?",
        "Show me the decile analysis",
        "Explain the KS statistic",
        "Compare XGBoost vs LightGBM",
        "Rejection strategy for top 2 deciles",
        "What are the main model limitations?",
        "How does an AI agent differ from a conventional model?",
        "What hyperparameters did the best model land on?",
        "How many defaults do we catch rejecting 20% of apps?",
    ]

    # Init agent once per session
    if "risk_agent" not in st.session_state:
        with st.spinner("Connecting to Bedrock…"):
            try:
                st.session_state.risk_agent = RiskAgent()
                st.session_state.agent_ok   = True
            except Exception as e:
                st.session_state.agent_ok  = False
                st.session_state.agent_err = str(e)
        st.session_state.agent_messages = []

    if not st.session_state.get("agent_ok", True):
        st.error(f"Could not connect to Bedrock: {st.session_state.get('agent_err','')}")
        st.info("Make sure the EC2 IAM role has `bedrock:InvokeModel` permission for `us-east-2`.")
        st.stop()

    # Sidebar controls
    with st.sidebar:
        st.markdown("---")
        if st.button("🔄 New conversation", use_container_width=True):
            st.session_state.risk_agent.reset()
            st.session_state.agent_messages = []
            st.rerun()
        st.markdown("**💡 Try asking:**")
        for s in SUGGESTIONS:
            if st.button(s, key=f"sug_{s}", use_container_width=True):
                st.session_state["_pending"] = s
        st.markdown("---")
        st.caption("🔐 Auth: EC2 IAM role (no API key needed)")
        st.caption("🤖 Model: claude-sonnet-4-5 (Bedrock)")
        st.caption("🔧 Tools: 6 available")

    # Welcome screen
    if not st.session_state.agent_messages:
        st.markdown("""
        <div class="chat-welcome">
          <h3>🤖 Risk Modeling Agent</h3>
          <p>I have live access to your trained model results, EDA statistics,<br>
          feature importance rankings, decile tables, and hyperparameter outcomes.<br>
          I use <b>tool calling</b> to pull real numbers — not memory.</p>
          <p style="margin-top:0.8rem; color:#aaa; font-size:0.85rem;">
          Try one of the suggestions in the sidebar, or type your own question below.
          </p>
        </div>
        """, unsafe_allow_html=True)

    else:
        # Render chat history
        for msg in st.session_state.agent_messages:
            role    = msg["role"]
            content = msg["content"]
            tools   = msg.get("tool_calls", [])

            if role == "user":
                st.markdown('<div class="chat-label-user">You</div>', unsafe_allow_html=True)
                st.markdown(f'<div class="chat-bubble-user">{content}</div>', unsafe_allow_html=True)
            else:
                st.markdown('<div class="chat-label-assistant">🤖 Agent</div>', unsafe_allow_html=True)
                for t in tools:
                    st.markdown(f'<div class="chat-bubble-tool">🔧 tool called: <b>{t}</b></div>',
                                unsafe_allow_html=True)
                st.markdown(f'<div class="chat-bubble-assistant">{content}</div>', unsafe_allow_html=True)

        st.markdown("<div style='margin-bottom:0.5rem'></div>", unsafe_allow_html=True)

    # Input
    pending    = st.session_state.pop("_pending", None)
    user_input = st.chat_input("Ask about the models, features, EDA, or scoring strategy…") or pending

    if user_input:
        st.session_state.agent_messages.append({"role":"user","content":user_input})

        tool_calls_made = []

        # Patch execute_tool to track which tools get called
        import modulos.agente.tools  as _tm
        import modulos.agente.agent  as _am
        _original = _tm.execute_tool

        def _tracked(name, params, data):
            tool_calls_made.append(name)
            return _original(name, params, data)

        _tm.execute_tool = _tracked
        _am.execute_tool = _tracked

        with st.spinner("🤖 Querying tools and reasoning…"):
            try:
                response = st.session_state.risk_agent.query(user_input)
            except Exception as e:
                response = f"⚠️ Error: {e}"

        _tm.execute_tool = _original
        _am.execute_tool = _original

        st.session_state.agent_messages.append({
            "role": "assistant",
            "content": response,
            "tool_calls": list(dict.fromkeys(tool_calls_made)),
        })
        st.rerun()
