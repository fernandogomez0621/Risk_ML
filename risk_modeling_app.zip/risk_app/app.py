"""
Credit Risk Origination — Classification Model
Senior Data Scientist Challenge
Streamlit application
"""

import os
import time
import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go

# ─── Page config (must be first) ────────────────────────────────────────────
st.set_page_config(
    page_title="Credit Risk — Risk Modeling Challenge",
    page_icon="🏦",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── CSS ────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .main-header {font-size:1.9rem; font-weight:700; color:#1a1a2e; margin-bottom:0.3rem;}
    .sub-header  {font-size:1rem;  color:#555;    margin-bottom:1.5rem;}
    .metric-card {
        background:#f0f7ff; border-radius:10px; padding:1.2rem;
        border-left:5px solid #4A90D9; margin:0.5rem 0;
    }
    .approve-badge {
        background:#d4edda; color:#155724;
        border-radius:8px; padding:0.8rem 1.5rem;
        font-size:1.4rem; font-weight:700; display:inline-block;
    }
    .reject-badge {
        background:#f8d7da; color:#721c24;
        border-radius:8px; padding:0.8rem 1.5rem;
        font-size:1.4rem; font-weight:700; display:inline-block;
    }
    .section-title {font-size:1.3rem; font-weight:600; margin:1rem 0 0.5rem;}
    .stAlert > div {border-radius:8px;}
</style>
""", unsafe_allow_html=True)

# ─── Sidebar navigation ──────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 🏦 Credit Risk App")
    page = st.radio(
        "",
        ["🏠 Overview", "📊 EDA", "🤖 Models", "🎯 Prediction", "💬 AI Agent"],
        label_visibility="collapsed",
    )
    st.markdown("---")
    st.markdown("**Risk Modeling Challenge**")
    st.markdown("Senior Data Scientist")
    st.markdown("---")
    st.caption("Dataset: 1,000 companies")
    st.caption("Features: 28 original → 61 engineered")
    st.caption("Models: 6 classifiers + HPO")

# ─── Load data & run pipeline ───────────────────────────────────────────────
# Import modules relative to app root
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from modulos.datos.loader import load_raw, engineer_features, compute_eda, train_models

@st.cache_data(show_spinner=False)
def get_pipeline():
    df_raw = load_raw()
    df_fe  = engineer_features(df_raw)
    eda    = compute_eda(df_raw)
    return df_raw, df_fe, eda

# Train separately so it can be triggered on demand
@st.cache_resource(show_spinner=False)
def get_trained_models():
    df_raw = load_raw()
    df_fe  = engineer_features(df_raw)
    return train_models(df_fe)


# ════════════════════════════════════════════════════════════════════════════
# PAGE: OVERVIEW
# ════════════════════════════════════════════════════════════════════════════
if page == "🏠 Overview":
    st.markdown('<p class="main-header">🏦 Credit Risk Origination Model</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">End-to-end classification pipeline — SERPRO & BACEN features → binary default prediction</p>', unsafe_allow_html=True)

    # Key stats
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Observations", "1,000")
    c2.metric("Features (raw)", "28")
    c3.metric("Features (total)", "61")
    c4.metric("Bad Rate", "14.6%")
    c5.metric("Models Trained", "6")

    st.markdown("---")

    col_left, col_right = st.columns(2)

    with col_left:
        st.markdown("#### 📌 Project Summary")
        st.markdown("""
        This application demonstrates a complete credit risk modeling pipeline for **SME origination**.

        **Data sources:**
        - **SERPRO** (7 vars): corporate structure, ownership, governance
        - **BACEN** (21 vars): credit bureau — utilization, delinquency, write-offs

        **Pipeline:**
        1. Exploratory Data Analysis with statistical tests
        2. Feature Engineering (33 new variables in 7 categories)
        3. Model training with 5-fold CV + RandomizedSearchCV HPO
        4. Single-observation scoring with risk decile assignment
        5. AI Agent for interactive result exploration
        """)

    with col_right:
        st.markdown("#### 🔑 Key Findings")
        st.markdown("""
        | Finding | Detail |
        |---|---|
        | **Strongest predictor** | `serpro__num_owners` (ρ=−0.287) |
        | **Top engineered feature** | `fe__is_sole_owner` — outperforms all originals |
        | **Significant features** | 22/28 (Mann-Whitney p<0.05) |
        | **Missing pattern** | Informative, not random — BACEN nulls = no credit |
        | **Best delinquency flag** | `has_writeoff_ever` (χ²=28.42, p=6.7e-7) |
        | **Class imbalance handling** | `scale_pos_weight` / `class_weight='balanced'` |
        | **Primary metric** | AUC-ROC (accuracy useless at 14.6% bad rate) |
        """)

    st.markdown("---")
    st.markdown("#### 🏗️ Deployment Architecture")
    st.markdown("""
    ```
    [SERPRO + BACEN APIs]  ──►  [Feature Engineering]  ──►  [XGBoost/LightGBM Scorer]
                                                                        │
    [Monitoring Layer]  ◄──  [Drift Detection PSI/CSI]  ◄──  [Decision Output]
         │                                                     (prob, decile, APPROVE/REJECT)
    [MLflow Registry]  ──►  [Champion/Challenger Framework]
    ```
    - **Latency target:** < 200ms real-time scoring
    - **Monitoring:** PSI/CSI rolling 30-day windows; alert if PSI > 0.25
    - **Limitations:** 1,000 obs (EPV ≈ 2.4), selection bias (reject inference needed)
    """)


# ════════════════════════════════════════════════════════════════════════════
# PAGE: EDA
# ════════════════════════════════════════════════════════════════════════════
elif page == "📊 EDA":
    from modulos.visualizaciones.eda_plots import (
        fig_target_distribution, fig_missing_values, fig_distributions_by_class,
        fig_spearman_correlation, fig_correlation_matrix, fig_mann_whitney,
        fig_bad_rate_by_flag,
    )

    st.markdown('<p class="main-header">📊 Exploratory Data Analysis</p>', unsafe_allow_html=True)

    with st.spinner("Loading data and computing EDA…"):
        df_raw, df_fe, eda = get_pipeline()

    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "Target & Missing", "Distributions", "Correlations",
        "Statistical Tests", "Feature Engineering"
    ])

    with tab1:
        c1, c2 = st.columns(2)
        with c1:
            st.plotly_chart(
                fig_target_distribution(eda["target_dist"], eda["bad_rate"]),
                use_container_width=True,
            )
        with c2:
            st.plotly_chart(fig_missing_values(eda["missing_df"]), use_container_width=True)

        st.markdown("#### Descriptive Statistics")
        desc_show = eda["desc"][["count", "mean", "std", "min", "50%", "max", "missing_pct", "bad_rate_corr"]].round(3)
        st.dataframe(desc_show, use_container_width=True)

    with tab2:
        key_vars = [
            "serpro__company_age_months", "bacen__max_account_age_months",
            "bacen__utilization_last_1m", "bacen__overdue_ratio_last_1m",
            "bacen__over30_ratio_last_1m", "bacen__over60_ratio_last_1m",
        ]
        st.plotly_chart(
            fig_distributions_by_class(df_raw, key_vars),
            use_container_width=True,
        )

        flag_vars = [
            "bacen__has_over30_last_1m", "bacen__has_over60_last_1m",
            "bacen__has_writeoff_last_12m", "bacen__has_writeoff_last_48m",
            "bacen__has_writeoff_ever",
        ]
        st.plotly_chart(fig_bad_rate_by_flag(df_raw, flag_vars), use_container_width=True)

    with tab3:
        c1, c2 = st.columns([1, 2])
        with c1:
            st.plotly_chart(
                fig_spearman_correlation(eda["spearman_corr"]),
                use_container_width=True,
            )
        with c2:
            st.plotly_chart(
                fig_correlation_matrix(eda["corr_matrix"]),
                use_container_width=True,
            )

    with tab4:
        st.markdown("#### Mann-Whitney U Tests (Good vs. Bad companies)")
        mw = eda["mw_df"]
        sig_count = int(mw["significant"].sum())
        st.info(f"**{sig_count}/{len(mw)}** features are statistically significant (p < 0.05)")
        st.plotly_chart(fig_mann_whitney(mw, top_n=20), use_container_width=True)

        st.markdown("#### Chi-Squared Tests — Binary Delinquency Flags")
        chi2 = eda["chi2_df"].copy()
        chi2["p_value"] = chi2["p_value"].map(lambda x: f"{x:.2e}")
        st.dataframe(chi2, use_container_width=True, hide_index=True)

    with tab5:
        st.markdown("#### Feature Engineering — 33 New Variables in 7 Categories")
        categories = {
            "Missing as Feature (3)": [
                "fe__has_no_bacen_data — BACEN = 0 means no credit history",
                "fe__missing_cc_data — Credit card data absent",
                "fe__missing_bacen_ratios — General BACEN data absent",
            ],
            "Age & Maturity (6)": [
                "fe__company_age_years", "fe__is_young_company (<24m)",
                "fe__is_very_young_company (<6m)", "fe__account_age_range",
                "fe__company_vs_max_account_age", "fe__account_to_company_age_ratio",
            ],
            "Corporate Governance (5)": [
                "fe__is_sole_owner ← #1 engineered feature (ρ=0.287)",
                "fe__owners_added_ratio", "fe__all_owners_are_new",
                "fe__owner_tenure_vs_company_age", "fe__has_non_executive_owners",
            ],
            "Composite Credit Stress (4)": [
                "fe__any_delinquency", "fe__severe_delinquency",
                "fe__delinquency_score (weighted)", "fe__writeoff_escalation",
            ],
            "Utilization Behavior (5)": [
                "fe__high_utilization (>80%)", "fe__very_high_utilization (>95%)",
                "fe__cc_utilization_excess", "fe__overdue_intensity", "fe__overdue_intensity_cc",
            ],
            "Domain Interactions (4)": [
                "fe__young_x_delinquency", "fe__sole_owner_x_young",
                "fe__high_util_x_delinquency", "fe__no_bacen_x_young",
            ],
            "Log Transforms (4)": [
                "fe__log_serpro__company_age_months",
                "fe__log_bacen__max_account_age_months",
                "fe__log_bacen__min_account_age_months",
                "fe__log_serpro__avg_owner_tenure_months",
            ],
        }
        for cat, feats in categories.items():
            with st.expander(f"**{cat}**"):
                for f in feats:
                    st.markdown(f"- `{f}`")

        # Show FE data sample
        st.markdown("#### Engineered Feature Sample")
        fe_cols = [c for c in df_fe.columns if c.startswith("fe__")]
        st.dataframe(df_fe[fe_cols].head(10), use_container_width=True)


# ════════════════════════════════════════════════════════════════════════════
# PAGE: MODELS
# ════════════════════════════════════════════════════════════════════════════
elif page == "🤖 Models":
    from modulos.visualizaciones.model_plots import (
        fig_roc_curves, fig_precision_recall, fig_metrics_comparison,
        fig_ks_curve, fig_confusion_matrix, fig_feature_importance,
        fig_score_distribution,
    )

    st.markdown('<p class="main-header">🤖 Model Evaluation</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">6 classifiers · 5-fold outer CV · RandomizedSearchCV HPO (15 iter, 3-fold inner)</p>', unsafe_allow_html=True)

    with st.spinner("Training models… this takes ~2–4 minutes on first run."):
        train_res = get_trained_models()

    models = train_res["models"]
    best_name = train_res["best_model_name"]
    y_true = train_res["y"]

    # Summary table
    st.markdown("#### Summary Table")
    rows = []
    for mn in sorted(models, key=lambda k: -models[k]["auc"]):
        info = models[mn]
        rows.append({
            "Model": mn,
            "AUC-ROC": f"{info['auc']:.4f}",
            "Gini": f"{info['gini']:.4f}",
            "KS": f"{info['ks']:.4f}",
            "Avg Precision": f"{info['ap']:.4f}",
            "Recall@KS": f"{info['recall_at_ks']:.3f}",
            "Precision@KS": f"{info['precision_at_ks']:.3f}",
            "Best": "⭐" if mn == best_name else "",
        })
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

    st.markdown("---")
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "ROC / PR Curves", "KS & Threshold", "Feature Importance",
        "Score Distribution", "Decile Analysis"
    ])

    with tab1:
        c1, c2 = st.columns(2)
        with c1:
            st.plotly_chart(fig_roc_curves(models), use_container_width=True)
        with c2:
            st.plotly_chart(fig_precision_recall(models, y_true), use_container_width=True)
        st.plotly_chart(fig_metrics_comparison(models), use_container_width=True)

    with tab2:
        sel_model = st.selectbox("Select model", list(models.keys()), index=list(models.keys()).index(best_name))
        info = models[sel_model]
        c1, c2 = st.columns(2)
        with c1:
            st.plotly_chart(fig_ks_curve(info, sel_model), use_container_width=True)
        with c2:
            st.plotly_chart(
                fig_confusion_matrix(info["confusion_matrix"], sel_model, info["ks_threshold"]),
                use_container_width=True,
            )
        st.markdown(f"""
        **At KS-optimal threshold ({info['ks_threshold']:.3f}):**
        - Bad recall: **{info['recall_at_ks']*100:.1f}%** of defaults captured
        - Precision: **{info['precision_at_ks']*100:.1f}%** (1 in {1/max(info['precision_at_ks'],0.001):.1f} rejections is a true bad)
        - Industry benchmark: KS > 0.40 = "good" origination model
        """)

        st.markdown("#### Optimal Hyperparameters")
        st.json(info["best_params"])

    with tab3:
        sel_fi = st.selectbox("Select model for importance", list(models.keys()), index=list(models.keys()).index(best_name), key="fi_sel")
        fi = models[sel_fi].get("feature_importance")
        if fi:
            top_n = st.slider("Top N features", 10, 40, 20)
            st.plotly_chart(fig_feature_importance(fi, top_n), use_container_width=True)
            eng_count = sum(1 for k in list(sorted(fi.items(), key=lambda x: -x[1]))[:top_n] if k[0].startswith("fe__"))
            st.info(f"**{eng_count}/{top_n}** top features are engineered (fe__ prefix) — confirms FE added genuine signal.")
        else:
            st.warning("Feature importance not available for this model.")

    with tab4:
        sel_dist = st.selectbox("Select model", list(models.keys()), index=list(models.keys()).index(best_name), key="dist_sel")
        info_d = models[sel_dist]
        st.plotly_chart(
            fig_score_distribution(info_d["oof_probs"], y_true, sel_dist, info_d["ks_threshold"]),
            use_container_width=True,
        )

    with tab5:
        decile_df = train_res["decile_df"]
        st.markdown(f"#### Decile Analysis — {best_name} (best model)")
        st.dataframe(decile_df, use_container_width=True, hide_index=True)
        st.markdown("""
        **How to read this:**
        - Decile 1 = lowest predicted risk (best applicants)
        - Decile 10 = highest predicted risk (worst applicants)
        - Perfect monotonic ordering = model ranks risk correctly
        - Rejecting deciles 9–10 (20% of apps) captures the majority of defaults
        """)


# ════════════════════════════════════════════════════════════════════════════
# PAGE: PREDICTION
# ════════════════════════════════════════════════════════════════════════════
elif page == "🎯 Prediction":
    from modulos.datos.loader import predict_single

    st.markdown('<p class="main-header">🎯 Real-Time Credit Scoring</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Enter company features to get a default probability, risk decile, and recommendation</p>', unsafe_allow_html=True)

    with st.spinner("Loading trained models…"):
        train_res = get_trained_models()

    models = train_res["models"]
    best_name = train_res["best_model_name"]

    sel_model = st.selectbox("Scoring model", list(models.keys()),
                              index=list(models.keys()).index(best_name))

    st.markdown("---")
    st.markdown("#### 📋 Company Inputs")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("**🏢 SERPRO — Corporate Structure**")
        company_age = st.number_input("Company age (months)", 0, 600, 36)
        num_owners = st.number_input("Number of owners", 1, 20, 2)
        num_owners_added = st.number_input("Owners added last 12m", 0, 10, 0)
        avg_owner_tenure = st.number_input("Avg owner tenure (months)", 0, 600, 24)
        num_key_exec = st.number_input("Key executive owners", 0, 10, 1)
        key_exec_fraction = st.slider("Key exec owner fraction", 0.0, 1.0, 0.5, 0.05)
        num_non_exec = st.number_input("Non-executive owners", 0, 10, 1)

    with col2:
        st.markdown("**🏦 BACEN — Credit Bureau**")
        min_acct_age = st.number_input("Min account age (months)", 0, 300, 24)
        max_acct_age = st.number_input("Max account age (months)", 0, 300, 48)
        has_bacen = st.selectbox("Has BACEN data last 1m", [1, 0], index=0)
        has_over30 = st.selectbox("Has 30+ DPD last 1m", [0, 1], index=0)
        has_over60 = st.selectbox("Has 60+ DPD last 1m", [0, 1], index=0)
        has_writeoff_12m = st.selectbox("Write-off last 12m", [0, 1], index=0)
        has_writeoff_48m = st.selectbox("Write-off last 48m", [0, 1], index=0)
        has_writeoff_ever = st.selectbox("Write-off ever", [0, 1], index=0)
        utilization = st.slider("Credit utilization last 1m", 0.0, 1.0, 0.3, 0.01)
        utilization_cc = st.slider("CC utilization last 1m", 0.0, 1.0, 0.2, 0.01)
        overdue_ratio = st.slider("Overdue ratio last 1m", 0.0, 1.0, 0.0, 0.01)
        over30_ratio = st.slider("30+ DPD ratio last 1m", 0.0, 1.0, 0.0, 0.01)

    score_btn = st.button("🔍 Score this company", type="primary", use_container_width=True)

    if score_btn:
        raw_input = {
            "serpro__company_age_months": company_age,
            "serpro__num_owners": num_owners,
            "serpro__num_owners_added_last_12m": num_owners_added,
            "serpro__avg_owner_tenure_months": avg_owner_tenure,
            "serpro__num_key_executive_owners": num_key_exec,
            "serpro__key_executive_owner_fraction": key_exec_fraction,
            "serpro__num_non_executive_owners": num_non_exec,
            "bacen__min_account_age_months": min_acct_age,
            "bacen__max_account_age_months": max_acct_age,
            "bacen__has_bacen_last_1m": has_bacen,
            "bacen__has_over30_last_1m": has_over30,
            "bacen__has_over60_last_1m": has_over60,
            "bacen__has_writeoff_last_12m": has_writeoff_12m,
            "bacen__has_writeoff_last_48m": has_writeoff_48m,
            "bacen__has_writeoff_ever": has_writeoff_ever,
            "bacen__utilization_last_1m": utilization,
            "bacen__utilization_cc_last_1m": utilization_cc,
            "bacen__overdue_ratio_last_1m": overdue_ratio,
            "bacen__over30_ratio_last_1m": over30_ratio,
            "bacen__over60_ratio_last_1m": 0.0,
            "bacen__over30_ratio_cc_last_1m": 0.0,
            "bacen__over60_ratio_cc_last_1m": 0.0,
            "bacen__overdue_ratio_cc_last_1m": 0.0,
            "bacen__due_in_30_ratio_last_1_month": 0.0,
            "bacen__due_in_30_ratio_cc_last_1_month": 0.0,
            "bacen__ratio_revolving_to_total_cc_last_1m": 0.0,
            "bacen__has_over30_cc_last_1m": 0.0,
            "bacen__has_over60_cc_last_1m": 0.0,
        }

        with st.spinner("Scoring…"):
            result = predict_single(train_res, sel_model, raw_input)

        st.markdown("---")
        st.markdown("### Scoring Result")

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Default Probability", f"{result['probability']*100:.2f}%")
        c2.metric("Risk Decile", f"{result['risk_decile']} / 10")
        c3.metric("KS Threshold", f"{result['ks_threshold']:.3f}")
        c4.metric("Model", sel_model.split()[0])

        decision = result["recommendation"]
        badge_class = "reject-badge" if decision == "REJECT" else "approve-badge"
        icon = "❌" if decision == "REJECT" else "✅"
        st.markdown(
            f'<div class="{badge_class}">{icon} {decision}</div>',
            unsafe_allow_html=True,
        )

        # Gauge chart
        fig = go.Figure(go.Indicator(
            mode="gauge+number",
            value=result["probability"] * 100,
            number={"suffix": "%", "valueformat": ".2f"},
            title={"text": "Default Probability"},
            gauge={
                "axis": {"range": [0, 100]},
                "bar": {"color": "#e74c3c" if result["prediction"] == 1 else "#2ecc71"},
                "steps": [
                    {"range": [0, 10], "color": "#d4edda"},
                    {"range": [10, 30], "color": "#fff3cd"},
                    {"range": [30, 100], "color": "#f8d7da"},
                ],
                "threshold": {
                    "line": {"color": "#4A90D9", "width": 3},
                    "thickness": 0.8,
                    "value": result["ks_threshold"] * 100,
                },
            },
        ))
        fig.update_layout(height=280, margin=dict(l=20, r=20, t=60, b=20))
        st.plotly_chart(fig, use_container_width=True)

        st.caption(f"Blue line = KS-optimal threshold ({result['ks_threshold']*100:.1f}%). "
                   f"Scores above this are classified as BAD (REJECT).")


# ════════════════════════════════════════════════════════════════════════════
# PAGE: AI AGENT
# ════════════════════════════════════════════════════════════════════════════
elif page == "💬 AI Agent":
    from modulos.agente.agent import RiskAgent

    st.markdown('<p class="main-header">💬 Risk Modeling AI Agent</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Ask anything about the models, EDA, features, or scoring strategy</p>', unsafe_allow_html=True)

    # API key input
    api_key = st.sidebar.text_input("🔑 Anthropic API Key", type="password",
                                     help="Get yours at console.anthropic.com")
    if not api_key:
        st.warning("Enter your Anthropic API key in the sidebar to use the AI Agent.")
        st.markdown("""
        **What can this agent do?**
        - Answer questions about model metrics (AUC, Gini, KS, AP)
        - Explain which features drive default predictions
        - Walk through the decile analysis and rejection strategy
        - Compare models and explain HPO results
        - Discuss credit risk concepts, limitations, and next steps
        - Reason about threshold choices and business trade-offs

        **Example questions:**
        - *"What's the best model and why?"*
        - *"Which features matter most for predicting default?"*
        - *"If I want to reject the riskiest 20%, how many defaults do I catch?"*
        - *"What's the difference between an AI agent and a conventional model?"*
        - *"What are the main limitations of this dataset?"*
        """)
        st.stop()

    # Load models + EDA
    with st.spinner("Loading models and EDA for the agent…"):
        df_raw, _, eda = get_pipeline()
        train_res = get_trained_models()

    # Init agent
    if "risk_agent" not in st.session_state or st.session_state.get("agent_api_key") != api_key:
        st.session_state.risk_agent = RiskAgent(api_key, train_res, eda)
        st.session_state.agent_api_key = api_key
        st.session_state.agent_messages = []

    with st.sidebar:
        if st.button("🔄 Reset conversation"):
            st.session_state.risk_agent.reset()
            st.session_state.agent_messages = []
            st.rerun()

        st.markdown("**💡 Suggested questions:**")
        suggestions = [
            "What's the best model?",
            "Which features drive default?",
            "Explain the KS statistic",
            "Rejection strategy for top decile",
            "What are the model limitations?",
            "AI agent vs conventional model?",
            "Show me the decile table",
            "Compare XGBoost vs LightGBM",
        ]
        for s in suggestions:
            if st.button(s, key=f"sug_{s}"):
                st.session_state["pending_message"] = s

    # Chat display
    for msg in st.session_state.agent_messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    # Handle suggestion click
    pending = st.session_state.pop("pending_message", None)
    user_input = st.chat_input("Ask about the risk model…") or pending

    if user_input:
        st.session_state.agent_messages.append({"role": "user", "content": user_input})
        with st.chat_message("user"):
            st.markdown(user_input)

        with st.chat_message("assistant"):
            with st.spinner("Agent is thinking…"):
                try:
                    response = st.session_state.risk_agent.query(user_input)
                    st.markdown(response)
                    st.session_state.agent_messages.append(
                        {"role": "assistant", "content": response}
                    )
                except Exception as e:
                    err_msg = f"Error: {str(e)}"
                    st.error(err_msg)
                    st.session_state.agent_messages.append(
                        {"role": "assistant", "content": err_msg}
                    )
