"""
run_pipeline.py
---------------
Run this ONCE before launching the Streamlit app.
It trains all models, computes EDA, and saves everything as JSONs to results/.

Usage:
    cd risk_app
    python run_pipeline.py

Takes ~10-25 min depending on EC2 instance size.
After this, the app loads instantly from JSON files.
"""

import os
import json
import time
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.model_selection import StratifiedKFold, cross_val_predict, RandomizedSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    roc_auc_score, roc_curve, average_precision_score,
    confusion_matrix, precision_score, recall_score
)
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
import warnings

warnings.filterwarnings("ignore")
np.random.seed(42)

RESULTS_DIR = os.path.join(os.path.dirname(__file__), "results")
DATA_PATH   = os.path.join(os.path.dirname(__file__), "data.csv")
os.makedirs(RESULTS_DIR, exist_ok=True)


def save(name, obj):
    path = os.path.join(RESULTS_DIR, f"{name}.json")
    with open(path, "w") as f:
        json.dump(obj, f, default=str)
    print(f"  ✅  Saved  results/{name}.json")


# ─── 1. Load raw data ────────────────────────────────────────────────────────

print("\n[1/4] Loading data…")
df = pd.read_csv(DATA_PATH)
print(f"      Shape: {df.shape}  |  Bad rate: {df['target'].mean()*100:.1f}%")


# ─── 2. Feature engineering ──────────────────────────────────────────────────

print("\n[2/4] Feature engineering…")

fe = df.copy()

# Missing as feature
fe["fe__has_no_bacen_data"]    = fe["bacen__has_bacen_last_1m"].apply(lambda x: 1 if x == 0 else 0)
fe["fe__missing_cc_data"]      = fe["bacen__utilization_cc_last_1m"].isnull().astype(int)
fe["fe__missing_bacen_ratios"] = fe["bacen__utilization_last_1m"].isnull().astype(int)

# Age & maturity
fe["fe__company_age_years"]          = fe["serpro__company_age_months"] / 12
fe["fe__is_young_company"]           = (fe["serpro__company_age_months"] < 24).astype(int)
fe["fe__is_very_young_company"]      = (fe["serpro__company_age_months"] < 6).astype(int)
fe["fe__account_age_range"]          = fe["bacen__max_account_age_months"] - fe["bacen__min_account_age_months"]
fe["fe__company_vs_max_account_age"] = fe["serpro__company_age_months"] - fe["bacen__max_account_age_months"]
fe["fe__account_to_company_age_ratio"] = np.where(
    fe["serpro__company_age_months"] > 0,
    fe["bacen__max_account_age_months"] / fe["serpro__company_age_months"], 0)

# Corporate governance
fe["fe__is_sole_owner"]            = (fe["serpro__num_owners"] == 1).astype(int)
fe["fe__owners_added_ratio"]       = np.where(fe["serpro__num_owners"] > 0,
    fe["serpro__num_owners_added_last_12m"] / fe["serpro__num_owners"], 0)
fe["fe__all_owners_are_new"]       = ((fe["serpro__num_owners_added_last_12m"] == fe["serpro__num_owners"])
    & (fe["serpro__num_owners"] > 0)).astype(int)
fe["fe__owner_tenure_vs_company_age"] = np.where(fe["serpro__company_age_months"] > 0,
    fe["serpro__avg_owner_tenure_months"] / fe["serpro__company_age_months"], 0)
fe["fe__has_non_executive_owners"] = (fe["serpro__num_non_executive_owners"] > 0).astype(int)

# Composite credit stress
fe["fe__any_delinquency"]    = ((fe["bacen__has_over30_last_1m"] == 1) | (fe["bacen__has_over60_last_1m"] == 1)).astype(int)
fe["fe__severe_delinquency"] = ((fe["bacen__has_over60_last_1m"] == 1) | (fe["bacen__has_writeoff_last_12m"] == 1)).astype(int)
fe["fe__delinquency_score"]  = (fe["bacen__has_over30_last_1m"].fillna(0) * 1
    + fe["bacen__has_over60_last_1m"].fillna(0) * 2
    + fe["bacen__has_writeoff_last_12m"].fillna(0) * 3
    + fe["bacen__has_writeoff_last_48m"].fillna(0) * 2
    + fe["bacen__has_writeoff_ever"].fillna(0) * 1)
fe["fe__writeoff_escalation"] = (fe["bacen__has_writeoff_last_12m"].fillna(0) * 3
    + fe["bacen__has_writeoff_last_48m"].fillna(0) * 2
    + fe["bacen__has_writeoff_ever"].fillna(0) * 1)

# Utilization behavior
fe["fe__high_utilization"]      = (fe["bacen__utilization_last_1m"] > 0.8).astype(int)
fe["fe__very_high_utilization"] = (fe["bacen__utilization_last_1m"] > 0.95).astype(int)
fe["fe__cc_utilization_excess"] = np.where(fe["bacen__utilization_last_1m"] > 0,
    fe["bacen__utilization_cc_last_1m"] / (fe["bacen__utilization_last_1m"] + 1e-6), 0)
fe["fe__overdue_intensity"]    = (fe["bacen__overdue_ratio_last_1m"].fillna(0)
    + fe["bacen__over30_ratio_last_1m"].fillna(0) + fe["bacen__over60_ratio_last_1m"].fillna(0))
fe["fe__overdue_intensity_cc"] = (fe["bacen__overdue_ratio_cc_last_1m"].fillna(0)
    + fe["bacen__over30_ratio_cc_last_1m"].fillna(0) + fe["bacen__over60_ratio_cc_last_1m"].fillna(0))

# Domain interactions
fe["fe__young_x_delinquency"]    = fe["fe__is_young_company"] * fe["fe__any_delinquency"]
fe["fe__sole_owner_x_young"]     = fe["fe__is_sole_owner"] * fe["fe__is_young_company"]
fe["fe__high_util_x_delinquency"]= fe["fe__high_utilization"] * fe["fe__any_delinquency"]
fe["fe__no_bacen_x_young"]       = fe["fe__has_no_bacen_data"] * fe["fe__is_young_company"]

# Log transforms
for col in ["serpro__company_age_months", "bacen__max_account_age_months",
            "bacen__min_account_age_months", "serpro__avg_owner_tenure_months"]:
    fe[f"fe__log_{col}"] = np.log1p(fe[col].fillna(0))

feature_cols = [c for c in fe.columns if c not in ["id", "target"]]
X = fe[feature_cols]
y = fe["target"]
print(f"      Features: {len(feature_cols)} total ({len([c for c in feature_cols if c.startswith('fe__')])} engineered)")


# ─── 3. EDA ──────────────────────────────────────────────────────────────────

print("\n[3/4] Computing EDA…")

original_features = [c for c in df.columns if c not in ["id", "target"]]

# Target distribution
target_dist = {int(k): int(v) for k, v in df["target"].value_counts().items()}

# Missing
missing_raw = df[original_features].isnull().sum()
missing_data = [
    {"feature": str(f), "missing_count": int(v), "missing_pct": round(v / len(df) * 100, 2)}
    for f, v in missing_raw.items() if v > 0
]

# Spearman correlations with target
spearman_corr = df[original_features].corrwith(df["target"], method="spearman").sort_values()
spearman_data = {str(k): round(float(v), 4) for k, v in spearman_corr.items()}

# Mann-Whitney
mw_results = []
for f in original_features:
    good = df.loc[df["target"] == 0, f].dropna()
    bad  = df.loc[df["target"] == 1, f].dropna()
    if len(good) > 5 and len(bad) > 5:
        stat, pval = stats.mannwhitneyu(good, bad, alternative="two-sided")
        mw_results.append({
            "variable": str(f), "U_statistic": round(float(stat), 1),
            "p_value": float(pval), "median_good": round(float(good.median()), 4),
            "median_bad": round(float(bad.median()), 4), "significant": bool(pval < 0.05),
        })
mw_results.sort(key=lambda x: x["p_value"])

# Chi-squared on binary flags
binary_vars = [c for c in original_features if df[c].dropna().isin([0, 1]).all() and df[c].nunique() <= 3]
chi2_results = []
for v in binary_vars:
    ct = pd.crosstab(df[v].fillna(-1), df["target"])
    chi2_val, p, dof, _ = stats.chi2_contingency(ct)
    chi2_results.append({"variable": str(v), "chi2": round(float(chi2_val), 2), "p_value": float(p), "dof": int(dof)})
chi2_results.sort(key=lambda x: -x["chi2"])

# Descriptive stats
desc = df[original_features].describe().T.round(4)
desc["missing_pct"] = df[original_features].isnull().mean() * 100
desc["spearman_corr"] = spearman_corr
desc_data = desc[["mean", "std", "min", "50%", "max", "missing_pct", "spearman_corr"]].round(4).to_dict(orient="index")
desc_data = {str(k): {str(kk): float(vv) if not pd.isna(vv) else None for kk, vv in v.items()} for k, v in desc_data.items()}

# Correlation matrix (original features only)
corr_matrix = df[original_features].corr(method="spearman").round(4)
corr_data = {
    "columns": [str(c) for c in corr_matrix.columns],
    "values": [[round(float(v), 4) if not pd.isna(v) else 0 for v in row] for row in corr_matrix.values]
}

# Bad rate by flag
flag_bad_rates = {}
for v in binary_vars:
    ct = df.groupby(v)["target"].mean() * 100
    flag_bad_rates[str(v)] = {str(int(k)): round(float(val), 2) for k, val in ct.items()}

# Save EDA JSONs
save("eda_summary", {
    "n_observations": len(df),
    "n_features_original": len(original_features),
    "n_features_engineered": len([c for c in feature_cols if c.startswith("fe__")]),
    "n_features_total": len(feature_cols),
    "bad_rate": round(float(df["target"].mean()), 4),
    "n_good": int(target_dist.get(0, 0)),
    "n_bad": int(target_dist.get(1, 0)),
})
save("eda_target_distribution", {"target_dist": target_dist, "bad_rate": round(float(df["target"].mean()), 4)})
save("eda_missing_values", {"missing_features": missing_data})
save("eda_spearman_correlations", {"correlations": spearman_data})
save("eda_mann_whitney", {"results": mw_results, "significant_count": sum(1 for r in mw_results if r["significant"])})
save("eda_chi2_flags", {"results": chi2_results})
save("eda_descriptive_stats", {"stats": desc_data})
save("eda_correlation_matrix", corr_data)
save("eda_flag_bad_rates", {"bad_rates_by_flag": flag_bad_rates})
print("      EDA complete.")


# ─── 4. Model training ───────────────────────────────────────────────────────

print("\n[4/4] Training models (this is the slow part)…")

imputer = SimpleImputer(strategy="median")
cv_outer = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_inner = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
bad_rate_val = float(y.mean())
scale_pos = (1 - bad_rate_val) / bad_rate_val

X_imp = pd.DataFrame(imputer.fit_transform(X), columns=feature_cols)

model_configs = {
    "LightGBM": {
        "model": lgb.LGBMClassifier(random_state=42, scale_pos_weight=scale_pos, verbose=-1),
        "params": {"n_estimators": [50, 100, 200], "learning_rate": [0.03, 0.05, 0.1],
                   "max_depth": [3, 4, 5], "num_leaves": [15, 31, 63],
                   "min_child_samples": [20, 50], "subsample": [0.7, 0.8, 1.0],
                   "colsample_bytree": [0.7, 0.8, 1.0], "reg_alpha": [0, 0.1, 0.5], "reg_lambda": [0, 0.1, 0.5]},
    },
    "XGBoost": {
        "model": xgb.XGBClassifier(random_state=42, scale_pos_weight=scale_pos, eval_metric="logloss", verbosity=0),
        "params": {"n_estimators": [50, 100, 200], "learning_rate": [0.03, 0.05, 0.1],
                   "max_depth": [3, 5, 6], "min_child_weight": [1, 3, 5],
                   "subsample": [0.7, 0.8, 1.0], "colsample_bytree": [0.6, 0.7, 0.8],
                   "reg_alpha": [0, 0.1, 0.5], "reg_lambda": [0.1, 1.0], "gamma": [0, 0.5, 1.0]},
    },
    "CatBoost": {
        "model": CatBoostClassifier(random_state=42, scale_pos_weight=scale_pos, verbose=0, allow_writing_files=False),
        "params": {"iterations": [50, 100, 200], "learning_rate": [0.03, 0.05, 0.1],
                   "depth": [4, 5, 6], "l2_leaf_reg": [1, 3, 5],
                   "min_data_in_leaf": [5, 10, 20], "bagging_temperature": [0, 0.5, 1.0]},
    },
    "Random Forest": {
        "model": RandomForestClassifier(random_state=42, class_weight="balanced"),
        "params": {"n_estimators": [100, 200], "max_depth": [4, 6, 8, None],
                   "min_samples_leaf": [5, 10, 20], "min_samples_split": [5, 10], "max_features": ["sqrt", 0.5]},
    },
    "Extra Trees": {
        "model": ExtraTreesClassifier(random_state=42, class_weight="balanced"),
        "params": {"n_estimators": [100, 200], "max_depth": [4, 6, 8, None],
                   "min_samples_leaf": [5, 10, 20], "min_samples_split": [5, 10], "max_features": ["sqrt", 0.5]},
    },
    "Logistic Regression": {
        "model": Pipeline([("imputer", SimpleImputer(strategy="median")),
                           ("scaler", StandardScaler()),
                           ("lr", LogisticRegression(class_weight="balanced", max_iter=1000, random_state=42))]),
        "params": {"lr__C": [0.01, 0.1, 1.0, 10.0], "lr__solver": ["lbfgs", "liblinear"]},
        "use_raw": True,
    },
}

all_model_results = {}

for name, cfg in model_configs.items():
    t0 = time.time()
    print(f"  → Training {name}…", end=" ", flush=True)

    use_raw = cfg.get("use_raw", False)
    X_train = X if use_raw else X_imp

    search = RandomizedSearchCV(cfg["model"], cfg["params"], n_iter=15,
                                scoring="roc_auc", cv=cv_inner, random_state=42, n_jobs=-1)
    search.fit(X_train, y)
    best_model = search.best_estimator_

    oof_probs = cross_val_predict(best_model, X_train, y, cv=cv_outer, method="predict_proba")[:, 1]

    auc = roc_auc_score(y, oof_probs)
    gini = 2 * auc - 1
    ap = average_precision_score(y, oof_probs)
    fpr, tpr, thresholds = roc_curve(y, oof_probs)
    ks = float(np.max(tpr - fpr))
    ks_threshold = float(thresholds[np.argmax(tpr - fpr)])

    preds_ks = (oof_probs >= ks_threshold).astype(int)
    cm = confusion_matrix(y, preds_ks)
    recall_val = recall_score(y, preds_ks)
    precision_val = precision_score(y, preds_ks, zero_division=0)

    fi = None
    if hasattr(best_model, "feature_importances_"):
        fi = {str(k): float(v) for k, v in zip(feature_cols, best_model.feature_importances_)}
    elif hasattr(best_model, "named_steps") and hasattr(best_model.named_steps.get("lr"), "coef_"):
        fi = {str(k): float(v) for k, v in zip(feature_cols, np.abs(best_model.named_steps["lr"].coef_[0]))}

    all_model_results[name] = {
        "auc": round(float(auc), 4),
        "gini": round(float(gini), 4),
        "ks": round(float(ks), 4),
        "ks_threshold": round(float(ks_threshold), 4),
        "ap": round(float(ap), 4),
        "recall_at_ks": round(float(recall_val), 4),
        "precision_at_ks": round(float(precision_val), 4),
        "confusion_matrix": cm.tolist(),
        "best_params": {str(k): str(v) for k, v in search.best_params_.items()},
        "oof_probs": [round(float(p), 6) for p in oof_probs],
        "feature_importance": fi,
        "fpr": [round(float(v), 6) for v in fpr],
        "tpr": [round(float(v), 6) for v in tpr],
        "thresholds": [round(float(v), 6) for v in thresholds],
    }
    elapsed = time.time() - t0
    print(f"AUC={auc:.4f}  KS={ks:.4f}  ({elapsed:.0f}s)")

# Best model
best_name = max(all_model_results, key=lambda k: all_model_results[k]["auc"])

# Decile analysis on best model
probs_arr = np.array(all_model_results[best_name]["oof_probs"])
y_arr = y.values
decile_df = pd.DataFrame({"prob": probs_arr, "target": y_arr})
decile_df["decile"] = pd.qcut(decile_df["prob"], 10, labels=False, duplicates="drop")
decile_df["decile"] = 10 - decile_df["decile"]
decile_rows = []
cumulative_bads = 0
total_bads = int(y_arr.sum())
for d in range(1, 11):
    group = decile_df[decile_df["decile"] == d]
    n = len(group)
    bads = int(group["target"].sum())
    cumulative_bads += bads
    decile_rows.append({
        "Decile": d, "Count": n, "Bads": bads,
        "Bad Rate": f"{bads/n*100:.1f}%" if n > 0 else "N/A",
        "Avg Prob": round(float(group["prob"].mean()), 3),
        "Cum Bad %": f"{cumulative_bads/total_bads*100:.1f}%",
    })

# Model comparison table
comparison = sorted(
    [{"model": k, **{m: v for m, v in all_model_results[k].items()
      if m in ["auc", "gini", "ks", "ap", "recall_at_ks", "precision_at_ks"]}}
     for k in all_model_results],
    key=lambda x: -x["auc"]
)

# Column means for imputation at scoring time
col_means = {str(k): float(v) for k, v in X_imp.mean().items()}

save("models_comparison", {"comparison": comparison, "best_model": best_name})
save("models_metrics", all_model_results)
save("models_decile_analysis", {"best_model": best_name, "decile_table": decile_rows})
save("models_feature_cols", {"feature_cols": feature_cols, "col_means": col_means})

print(f"\n✅  Pipeline complete! Best model: {best_name} (AUC={all_model_results[best_name]['auc']:.4f})")
print(f"    Results saved to: {RESULTS_DIR}/")
print(f"    Now run: streamlit run app.py --server.port 8502 --server.address 0.0.0.0")
