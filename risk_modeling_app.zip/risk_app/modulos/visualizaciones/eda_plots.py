"""EDA visualization helpers using Plotly."""

import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

COLORS = {
    "good": "#2ecc71",
    "bad": "#e74c3c",
    "primary": "#4A90D9",
    "secondary": "#E8743B",
    "neutral": "#95a5a6",
    "bg": "#f8f9fa",
}


def fig_target_distribution(target_dist: dict, bad_rate: float) -> go.Figure:
    labels = ["0 — Good", "1 — Bad"]
    values = [target_dist.get(0, 0), target_dist.get(1, 0)]
    colors = [COLORS["good"], COLORS["bad"]]

    fig = go.Figure()
    fig.add_trace(
        go.Bar(
            x=labels,
            y=values,
            marker_color=colors,
            text=[f"{v}<br>({v/sum(values)*100:.1f}%)" for v in values],
            textposition="outside",
        )
    )
    fig.update_layout(
        title=f"Target Distribution — Bad Rate: {bad_rate*100:.1f}%",
        height=350,
        template="plotly_white",
        yaxis_title="Count",
        showlegend=False,
    )
    return fig


def fig_missing_values(missing_df: pd.DataFrame) -> go.Figure:
    mdf = missing_df[missing_df["missing_count"] > 0].sort_values("missing_pct")
    colors = [
        COLORS["bad"] if v > 30 else COLORS["secondary"] if v > 20 else COLORS["primary"]
        for v in mdf["missing_pct"]
    ]
    fig = go.Figure(
        go.Bar(
            x=mdf["missing_pct"],
            y=mdf["feature"].str.replace("bacen__", "b__").str.replace("serpro__", "s__"),
            orientation="h",
            marker_color=colors,
            text=mdf["missing_pct"].map(lambda v: f"{v:.1f}%"),
            textposition="outside",
        )
    )
    fig.update_layout(
        title="Missing Values by Feature",
        height=400,
        template="plotly_white",
        xaxis_title="Missing %",
    )
    return fig


def fig_distributions_by_class(df: pd.DataFrame, features: list) -> go.Figure:
    n_cols = 3
    n_rows = int(np.ceil(len(features) / n_cols))
    fig = make_subplots(rows=n_rows, cols=n_cols, subplot_titles=features)

    for i, feat in enumerate(features):
        row = i // n_cols + 1
        col = i % n_cols + 1
        for tval, color, label in [(0, COLORS["good"], "Good"), (1, COLORS["bad"], "Bad")]:
            data = df.loc[df["target"] == tval, feat].dropna()
            fig.add_trace(
                go.Histogram(
                    x=data,
                    name=label,
                    marker_color=color,
                    opacity=0.6,
                    histnorm="probability density",
                    showlegend=(i == 0),
                    legendgroup=label,
                ),
                row=row,
                col=col,
            )
    fig.update_layout(
        height=300 * n_rows,
        title="Key Feature Distributions by Risk Class",
        template="plotly_white",
        barmode="overlay",
    )
    return fig


def fig_spearman_correlation(spearman_corr: pd.Series) -> go.Figure:
    colors = [COLORS["bad"] if v > 0 else COLORS["good"] for v in spearman_corr.values]
    labels = [
        c.replace("bacen__", "b__").replace("serpro__", "s__").replace("fe__", "fe__")
        for c in spearman_corr.index
    ]
    fig = go.Figure(
        go.Bar(
            x=spearman_corr.values,
            y=labels,
            orientation="h",
            marker_color=colors,
            text=[f"{v:.3f}" for v in spearman_corr.values],
            textposition="outside",
        )
    )
    fig.update_layout(
        title="Spearman Correlation with Target",
        height=max(500, len(spearman_corr) * 14),
        template="plotly_white",
        xaxis_title="Correlation",
    )
    return fig


def fig_correlation_matrix(corr_matrix: pd.DataFrame) -> go.Figure:
    labels = [
        c.replace("bacen__", "b__").replace("serpro__", "s__")
        for c in corr_matrix.columns
    ]
    fig = go.Figure(
        go.Heatmap(
            z=corr_matrix.values,
            x=labels,
            y=labels,
            colorscale="RdBu",
            zmid=0,
            zmin=-1,
            zmax=1,
            colorbar_title="ρ",
        )
    )
    fig.update_layout(
        title="Spearman Correlation Matrix",
        height=600,
        template="plotly_white",
    )
    return fig


def fig_mann_whitney(mw_df: pd.DataFrame, top_n: int = 15) -> go.Figure:
    df = mw_df.head(top_n).copy()
    df["-log10_p"] = -np.log10(df["p_value"].clip(1e-20))
    colors = [COLORS["bad"] if s else COLORS["neutral"] for s in df["significant"]]
    labels = [
        c.replace("bacen__", "b__").replace("serpro__", "s__").replace("fe__", "fe__")
        for c in df["variable"]
    ]
    fig = go.Figure(
        go.Bar(
            x=df["-log10_p"],
            y=labels,
            orientation="h",
            marker_color=colors,
            text=[f"p={p:.1e}" for p in df["p_value"]],
            textposition="outside",
        )
    )
    fig.add_vline(x=-np.log10(0.05), line_dash="dash", line_color="gray",
                  annotation_text="p=0.05")
    fig.update_layout(
        title=f"Mann-Whitney U — Top {top_n} Discriminating Features",
        height=420,
        template="plotly_white",
        xaxis_title="-log₁₀(p-value)",
    )
    return fig


def fig_bad_rate_by_flag(df: pd.DataFrame, flag_vars: list) -> go.Figure:
    n = len(flag_vars)
    fig = make_subplots(rows=1, cols=n, subplot_titles=[
        v.replace("bacen__", "").replace("_last_1m", "").replace("_last_12m", "_12m")
        .replace("_last_48m", "_48m")
        for v in flag_vars
    ])
    for i, var in enumerate(flag_vars, 1):
        ct = df.groupby(var)["target"].mean() * 100
        fig.add_trace(
            go.Bar(
                x=ct.index.astype(str),
                y=ct.values,
                marker_color=[COLORS["good"], COLORS["bad"]][: len(ct)],
                text=[f"{v:.1f}%" for v in ct.values],
                textposition="outside",
                showlegend=False,
            ),
            row=1,
            col=i,
        )
    fig.update_layout(
        height=350,
        title="Bad Rate by Delinquency Flags",
        template="plotly_white",
    )
    return fig
