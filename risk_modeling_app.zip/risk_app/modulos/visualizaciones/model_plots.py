"""Model evaluation visualization helpers."""

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

COLORS = {
    "LightGBM": "#4A90D9",
    "XGBoost": "#E8743B",
    "CatBoost": "#8E44AD",
    "Random Forest": "#27AE60",
    "Extra Trees": "#F39C12",
    "Logistic Regression": "#2C3E50",
}


def fig_roc_curves(models: dict) -> go.Figure:
    fig = go.Figure()
    fig.add_shape(type="line", x0=0, y0=0, x1=1, y1=1,
                  line=dict(dash="dash", color="gray"))
    for name, info in sorted(models.items(), key=lambda x: -x[1]["auc"]):
        fig.add_trace(go.Scatter(
            x=info["fpr"],
            y=info["tpr"],
            mode="lines",
            name=f"{name} (AUC={info['auc']:.4f})",
            line=dict(color=COLORS.get(name, "#999"), width=2),
        ))
    fig.update_layout(
        title="ROC Curves — 5-Fold Out-of-Fold",
        xaxis_title="False Positive Rate",
        yaxis_title="True Positive Rate",
        height=450,
        template="plotly_white",
        legend=dict(x=0.6, y=0.05),
    )
    return fig


def fig_precision_recall(models: dict, y_true) -> go.Figure:
    from sklearn.metrics import precision_recall_curve, average_precision_score
    y = np.array(y_true)
    fig = go.Figure()
    for name, info in sorted(models.items(), key=lambda x: -x[1]["ap"]):
        probs = np.array(info["oof_probs"])
        precision, recall, _ = precision_recall_curve(y, probs)
        ap = info["ap"]
        fig.add_trace(go.Scatter(
            x=recall, y=precision,
            mode="lines",
            name=f"{name} (AP={ap:.4f})",
            line=dict(color=COLORS.get(name, "#999"), width=2),
        ))
    fig.update_layout(
        title="Precision-Recall Curves — 5-Fold Out-of-Fold",
        xaxis_title="Recall",
        yaxis_title="Precision",
        height=450,
        template="plotly_white",
        legend=dict(x=0.6, y=0.8),
    )
    return fig


def fig_metrics_comparison(models: dict) -> go.Figure:
    names = list(models.keys())
    metrics = ["auc", "gini", "ks", "ap"]
    metric_labels = ["AUC-ROC", "Gini", "KS", "Avg Precision"]

    fig = make_subplots(rows=1, cols=4, subplot_titles=metric_labels)
    for col_i, (metric, label) in enumerate(zip(metrics, metric_labels), 1):
        vals = [models[n][metric] for n in names]
        colors_bar = [COLORS.get(n, "#999") for n in names]
        fig.add_trace(
            go.Bar(
                x=names,
                y=vals,
                marker_color=colors_bar,
                text=[f"{v:.4f}" for v in vals],
                textposition="outside",
                showlegend=False,
            ),
            row=1, col=col_i,
        )
    fig.update_layout(
        height=400,
        title="Model Comparison — Key Metrics",
        template="plotly_white",
    )
    return fig


def fig_ks_curve(model_info: dict, model_name: str) -> go.Figure:
    fpr = np.array(model_info["fpr"])
    tpr = np.array(model_info["tpr"])
    ks = model_info["ks"]
    ks_idx = np.argmax(tpr - fpr)

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=fpr, y=tpr, name="TPR (Bad)", line=dict(color="#e74c3c", width=2)))
    fig.add_trace(go.Scatter(x=fpr, y=fpr, name="FPR (Good)", line=dict(color="#2ecc71", width=2)))
    fig.add_shape(
        type="line",
        x0=fpr[ks_idx], y0=fpr[ks_idx],
        x1=fpr[ks_idx], y1=tpr[ks_idx],
        line=dict(color="#4A90D9", width=2, dash="dash"),
    )
    fig.add_annotation(
        x=fpr[ks_idx], y=(fpr[ks_idx] + tpr[ks_idx]) / 2,
        text=f"KS={ks:.3f}",
        showarrow=True, arrowhead=2,
    )
    fig.update_layout(
        title=f"KS Curve — {model_name}",
        xaxis_title="Threshold (ordered by score)",
        yaxis_title="Cumulative %",
        height=400,
        template="plotly_white",
    )
    return fig


def fig_confusion_matrix(cm_list: list, model_name: str, threshold: float) -> go.Figure:
    cm = np.array(cm_list)
    labels = ["Good (0)", "Bad (1)"]
    z_text = [[str(v) for v in row] for row in cm]
    fig = go.Figure(go.Heatmap(
        z=cm,
        x=labels,
        y=labels,
        text=z_text,
        texttemplate="%{text}",
        colorscale=[[0, "#f8f9fa"], [1, "#e74c3c"]],
        showscale=False,
    ))
    fig.update_layout(
        title=f"Confusion Matrix — {model_name} (threshold={threshold:.3f})",
        xaxis_title="Predicted",
        yaxis_title="Actual",
        height=350,
        template="plotly_white",
    )
    return fig


def fig_feature_importance(fi_dict: dict, top_n: int = 20) -> go.Figure:
    if not fi_dict:
        return go.Figure().update_layout(title="No feature importance available")
    items = sorted(fi_dict.items(), key=lambda x: x[1], reverse=True)[:top_n]
    names, vals = zip(*items)
    short_names = [
        n.replace("bacen__", "b__").replace("serpro__", "s__").replace("fe__", "fe__")
        for n in names
    ]
    colors = ["#e74c3c" if "fe__" in n else "#4A90D9" for n in names]
    fig = go.Figure(go.Bar(
        x=list(vals)[::-1],
        y=list(short_names)[::-1],
        orientation="h",
        marker_color=list(colors)[::-1],
    ))
    fig.update_layout(
        title=f"Top {top_n} Feature Importance (red=engineered)",
        height=500,
        template="plotly_white",
        xaxis_title="Importance",
    )
    return fig


def fig_score_distribution(oof_probs: list, y_true, model_name: str, threshold: float) -> go.Figure:
    probs = np.array(oof_probs)
    y = np.array(y_true)
    fig = go.Figure()
    for tval, color, label in [(0, "#2ecc71", "Good"), (1, "#e74c3c", "Bad")]:
        fig.add_trace(go.Histogram(
            x=probs[y == tval],
            name=label,
            marker_color=color,
            opacity=0.6,
            histnorm="probability density",
            nbinsx=40,
        ))
    fig.add_vline(x=threshold, line_dash="dash", line_color="#4A90D9",
                  annotation_text=f"KS threshold={threshold:.3f}")
    fig.update_layout(
        title=f"Score Distribution by Class — {model_name}",
        xaxis_title="Predicted Probability",
        yaxis_title="Density",
        height=380,
        template="plotly_white",
        barmode="overlay",
    )
    return fig
