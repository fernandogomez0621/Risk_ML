"""
tools.py
--------
Tool definitions and execution for the Risk Modeling AI Agent.
All tools read from the local results/ folder (pre-computed by run_pipeline.py).
Follows the exact same pattern as the example app's agente.py.
"""

import json
import os

RESULTS_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "results")


# ─── Data loader with cache ──────────────────────────────────────────────────

class ResultsData:
    """Cache of JSONs from the results/ folder. Same pattern as DatosS3 in example."""

    def __init__(self):
        self._cache = {}

    def load(self, name: str) -> dict:
        if name not in self._cache:
            path = os.path.join(RESULTS_DIR, f"{name}.json")
            try:
                with open(path) as f:
                    self._cache[name] = json.load(f)
            except FileNotFoundError:
                self._cache[name] = {"error": f"File not found: {name}.json — run run_pipeline.py first"}
            except Exception as e:
                self._cache[name] = {"error": str(e)}
        return self._cache[name]

    # EDA
    @property
    def eda_summary(self):           return self.load("eda_summary")
    @property
    def eda_target(self):            return self.load("eda_target_distribution")
    @property
    def eda_missing(self):           return self.load("eda_missing_values")
    @property
    def eda_spearman(self):          return self.load("eda_spearman_correlations")
    @property
    def eda_mann_whitney(self):      return self.load("eda_mann_whitney")
    @property
    def eda_chi2(self):              return self.load("eda_chi2_flags")
    @property
    def eda_desc(self):              return self.load("eda_descriptive_stats")
    @property
    def eda_corr_matrix(self):       return self.load("eda_correlation_matrix")
    @property
    def eda_flag_bad_rates(self):    return self.load("eda_flag_bad_rates")

    # Models
    @property
    def models_comparison(self):     return self.load("models_comparison")
    @property
    def models_metrics(self):        return self.load("models_metrics")
    @property
    def models_decile(self):         return self.load("models_decile_analysis")
    @property
    def models_feature_cols(self):   return self.load("models_feature_cols")


# ─── Tool definitions ────────────────────────────────────────────────────────

TOOLS = [
    {
        "name": "get_model_metrics",
        "description": (
            "Returns performance metrics for one or all trained models. "
            "Use when asked about model performance, best model, AUC, Gini, KS, Average Precision, "
            "recall, precision, confusion matrix, or hyperparameter tuning results."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "model_name": {
                    "type": "string",
                    "description": (
                        "Model name: 'LightGBM', 'XGBoost', 'CatBoost', 'Random Forest', "
                        "'Extra Trees', 'Logistic Regression', or 'all' for the full comparison table."
                    ),
                }
            },
            "required": ["model_name"],
        },
    },
    {
        "name": "get_feature_importance",
        "description": (
            "Returns the top-N most important features for a given model. "
            "Use when asked about which variables drive predictions, risk drivers, "
            "variable selection, or the value of feature engineering."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "model_name": {
                    "type": "string",
                    "description": "Model name (not 'all'). Defaults to the best model.",
                },
                "top_n": {
                    "type": "integer",
                    "description": "Number of top features to return (default 15).",
                },
            },
            "required": ["model_name"],
        },
    },
    {
        "name": "get_eda_statistics",
        "description": (
            "Returns EDA statistics: target distribution, missing rates, Spearman correlations "
            "with target, Mann-Whitney significance tests, chi-squared tests on binary flags, "
            "and bad rates per flag. Use when asked about data quality, feature distributions, "
            "data imbalance, or variable importance from exploratory analysis."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "section": {
                    "type": "string",
                    "description": (
                        "'summary' for overall dataset stats, "
                        "'target' for class distribution, "
                        "'missing' for missing value rates, "
                        "'correlations' for Spearman with target, "
                        "'mann_whitney' for significance tests, "
                        "'chi2' for binary flag chi-squared tests, "
                        "'flag_bad_rates' for bad rate per delinquency flag, "
                        "or 'all' for everything."
                    ),
                }
            },
            "required": ["section"],
        },
    },
    {
        "name": "get_decile_analysis",
        "description": (
            "Returns the decile risk table for the best model: count, bads, bad rate per decile, "
            "average predicted probability, and cumulative bad capture rate. "
            "Use when asked about risk segmentation, rejection strategy, cutoff analysis, "
            "portfolio concentration, or how many defaults are captured at a given rejection rate."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "get_threshold_analysis",
        "description": (
            "Returns confusion matrix metrics at the KS-optimal threshold for a given model: "
            "recall (bad capture rate), precision, threshold value, TP, FP, TN, FN counts. "
            "Use when asked about the decision threshold, operational cutoff, approval/rejection policy, "
            "or the trade-off between catching defaults and rejecting good applicants."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "model_name": {
                    "type": "string",
                    "description": "Model name. Defaults to the best model if omitted.",
                }
            },
            "required": ["model_name"],
        },
    },
    {
        "name": "get_best_model_params",
        "description": (
            "Returns the optimal hyperparameters found by RandomizedSearchCV for a given model. "
            "Use when asked about hyperparameter tuning results, model configuration, "
            "or why a particular model performed best."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "model_name": {
                    "type": "string",
                    "description": "Model name (not 'all').",
                }
            },
            "required": ["model_name"],
        },
    },
]


# ─── Tool execution ──────────────────────────────────────────────────────────

def execute_tool(name: str, params: dict, data: ResultsData) -> str:
    """Execute a tool call and return result as JSON string. Same interface as example app."""

    metrics = data.models_metrics
    comparison = data.models_comparison
    best_name = comparison.get("best_model", "XGBoost")

    if name == "get_model_metrics":
        model_name = params.get("model_name", "all")
        if model_name == "all":
            table = comparison.get("comparison", [])
            return json.dumps({
                "comparison_table": table,
                "best_model": best_name,
                "note": "Sorted by AUC-ROC descending. All metrics from 5-fold stratified outer CV.",
            }, default=str)
        elif model_name in metrics:
            info = metrics[model_name]
            return json.dumps({
                "model": model_name,
                "AUC_ROC": info.get("auc"),
                "Gini": info.get("gini"),
                "KS": info.get("ks"),
                "Avg_Precision": info.get("ap"),
                "Recall_at_KS_threshold": info.get("recall_at_ks"),
                "Precision_at_KS_threshold": info.get("precision_at_ks"),
                "KS_threshold": info.get("ks_threshold"),
                "confusion_matrix_at_ks": info.get("confusion_matrix"),
                "best_params": info.get("best_params"),
            }, default=str)
        else:
            return json.dumps({"error": f"Model '{model_name}' not found. Available: {list(metrics.keys())}"})

    elif name == "get_feature_importance":
        model_name = params.get("model_name", best_name)
        top_n = int(params.get("top_n", 15))
        if model_name not in metrics:
            return json.dumps({"error": f"Model '{model_name}' not found."})
        fi = metrics[model_name].get("feature_importance")
        if not fi:
            return json.dumps({"note": f"{model_name} does not expose feature importances."})
        sorted_fi = sorted(fi.items(), key=lambda x: x[1], reverse=True)[:top_n]
        engineered_count = sum(1 for k, _ in sorted_fi if k.startswith("fe__"))
        return json.dumps({
            "model": model_name,
            "top_features": [
                {"rank": i+1, "feature": k, "importance": round(float(v), 6),
                 "engineered": k.startswith("fe__")}
                for i, (k, v) in enumerate(sorted_fi)
            ],
            "engineered_features_in_top": engineered_count,
            "note": f"{engineered_count}/{top_n} top features are engineered (fe__ prefix)",
        }, default=str)

    elif name == "get_eda_statistics":
        section = params.get("section", "all")
        result = {}
        if section in ("all", "summary"):
            result["summary"] = data.eda_summary
        if section in ("all", "target"):
            result["target_distribution"] = data.eda_target
        if section in ("all", "missing"):
            result["missing_values"] = data.eda_missing
        if section in ("all", "correlations"):
            sc = data.eda_spearman.get("correlations", {})
            # Top 10 positive and top 5 negative
            sorted_sc = sorted(sc.items(), key=lambda x: x[1])
            result["top_negative_correlations"] = {k: v for k, v in sorted_sc[:5]}
            result["top_positive_correlations"] = {k: v for k, v in sorted_sc[-10:][::-1]}
        if section in ("all", "mann_whitney"):
            mw = data.eda_mann_whitney
            result["mann_whitney"] = {
                "significant_count": mw.get("significant_count"),
                "total_tested": len(mw.get("results", [])),
                "top_10_discriminating": mw.get("results", [])[:10],
            }
        if section in ("all", "chi2"):
            result["chi2_tests"] = data.eda_chi2.get("results", [])[:10]
        if section in ("all", "flag_bad_rates"):
            result["bad_rates_by_flag"] = data.eda_flag_bad_rates.get("bad_rates_by_flag", {})
        return json.dumps(result, default=str)

    elif name == "get_decile_analysis":
        decile = data.models_decile
        return json.dumps({
            "best_model": decile.get("best_model"),
            "decile_table": decile.get("decile_table", []),
            "interpretation": (
                "Decile 1 = lowest risk (best applicants, lowest predicted probability). "
                "Decile 10 = highest risk. "
                "Rejecting deciles 9-10 (20% of applicants) captures the majority of defaults."
            ),
        }, default=str)

    elif name == "get_threshold_analysis":
        model_name = params.get("model_name", best_name)
        if model_name not in metrics:
            return json.dumps({"error": f"Model '{model_name}' not found."})
        info = metrics[model_name]
        cm = info.get("confusion_matrix", [[0, 0], [0, 0]])
        tn, fp, fn, tp = cm[0][0], cm[0][1], cm[1][0], cm[1][1]
        ks_thr = info.get("ks_threshold", 0)
        rec = info.get("recall_at_ks", 0)
        prec = info.get("precision_at_ks", 0)
        return json.dumps({
            "model": model_name,
            "ks_threshold": ks_thr,
            "recall_bad_capture": rec,
            "precision_among_rejections": prec,
            "true_negatives": tn,
            "false_positives": fp,
            "false_negatives": fn,
            "true_positives": tp,
            "interpretation": (
                f"At threshold {ks_thr:.3f}: "
                f"the model captures {rec*100:.1f}% of defaulting companies (bad recall). "
                f"Of all rejections, {prec*100:.1f}% are true defaults "
                f"(1 in {round(1/max(prec, 0.001), 1)} rejections is an actual bad). "
                f"In origination, approving a bad typically costs 5-10x more than rejecting a good."
            ),
        }, default=str)

    elif name == "get_best_model_params":
        model_name = params.get("model_name", best_name)
        if model_name not in metrics:
            return json.dumps({"error": f"Model '{model_name}' not found."})
        return json.dumps({
            "model": model_name,
            "best_params": metrics[model_name].get("best_params", {}),
            "note": "Found via RandomizedSearchCV (15 iterations, 3-fold inner CV, optimizing AUC-ROC)",
        }, default=str)

    return json.dumps({"error": f"Unknown tool: '{name}'"})
