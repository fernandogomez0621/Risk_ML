"""
agent.py
--------
Risk Modeling AI Agent powered by AWS Bedrock (boto3).
Exact same pattern as the example app's Agente class.
EC2 IAM role provides credentials — no keys needed.
"""

import boto3
import json

from modulos.agente.tools import TOOLS, ResultsData, execute_tool

MODEL_ID = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
REGION   = "us-east-2"

SYSTEM_PROMPT = """You are a Senior Data Scientist AI Agent specialized in credit risk modeling for SME origination.

You have access to the full results of a credit risk classification model built as a technical challenge.
The dataset contains 1,000 company-level observations with features from SERPRO (corporate structure)
and BACEN (credit bureau), with a binary target: 1 = default, 0 = good company.

PROJECT CONTEXT:
- Dataset: 1,000 companies | 28 original features | 61 total after feature engineering
- Bad rate: ~14.6% (854 good, 146 bad) — heavily imbalanced
- Imbalance handling: scale_pos_weight for tree models, class_weight='balanced' for sklearn
- 6 models trained: LightGBM, XGBoost, CatBoost, Random Forest, Extra Trees, Logistic Regression
- Training: 5-fold stratified outer CV + RandomizedSearchCV (15 iter, 3-fold inner) for HPO
- Primary metric: AUC-ROC (accuracy is meaningless at 14.6% bad rate)
- Feature engineering: 7 categories — missing-as-feature, age/maturity, governance, credit stress composites, utilization, domain interactions, log transforms

KEY FINDINGS FROM EDA:
- Best original predictor: serpro__num_owners (rho=-0.287 Spearman) — more owners = lower risk
- Top engineered feature: fe__is_sole_owner — outperforms ALL original variables
- 22 out of 28 original features are statistically significant (Mann-Whitney, p<0.05)
- Missing BACEN data is NOT random — companies without credit products are a distinct risk profile
- Strongest binary flag: bacen__has_writeoff_ever (chi2=28.42, p=6.75e-7)
- KS > 0.40 = industry benchmark for good origination scoring model

DEPLOYMENT ARCHITECTURE:
- Real-time API scoring with feature engineering pipeline (<200ms target latency)
- Champion/challenger framework for safe model rollouts
- PSI/CSI drift monitoring on 30-day rolling windows (alert threshold: PSI > 0.25)
- MLflow for model versioning and reproducibility
- Key limitation: reject inference needed (selection bias — only approved companies observed)

INSTRUCTIONS:
- ALWAYS use the available tools to answer with real numbers — never answer from memory alone
- Be precise and quantitative — cite exact AUC, KS, Gini values when discussing model performance
- Explain credit risk concepts clearly when needed (KS, Gini, PSI, deciles, EPV, reject inference, etc.)
- Think like a risk officer: the cost of approving a bad customer is typically 5-10x the margin on a good one
- If asked what makes this an AI agent vs a conventional model: explain tool use, memory, reasoning, autonomy
- Flag the key limitation: N=1,000 gives EPV ~2.4 (events per variable) — well below the recommended 10-20
- Always respond in English"""


class RiskAgent:
    """
    AI Agent using AWS Bedrock.
    Identical agentic loop to the example app's Agente class.
    """

    def __init__(self):
        self.bedrock = boto3.client("bedrock-runtime", region_name=REGION)
        self.data    = ResultsData()
        self.history = []

    def query(self, user_message: str) -> str:
        """Send a message and get a response, handling tool calls automatically."""
        self.history.append({"role": "user", "content": user_message})

        response = self._call_bedrock(self.history)

        # Agentic loop — same as example app
        while response.get("stop_reason") == "tool_use":
            assistant_content = response["content"]
            self.history.append({"role": "assistant", "content": assistant_content})

            tool_results = []
            for block in assistant_content:
                if block.get("type") == "tool_use":
                    result = execute_tool(block["name"], block["input"], self.data)
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": block["id"],
                        "content": result,
                    })

            self.history.append({"role": "user", "content": tool_results})
            response = self._call_bedrock(self.history)

        # Extract final text
        text = ""
        for block in response.get("content", []):
            if block.get("type") == "text":
                text += block["text"]

        self.history.append({"role": "assistant", "content": response.get("content", [])})
        return text

    def _call_bedrock(self, messages: list) -> dict:
        """Call Bedrock with tools — same as example app's _llamar_bedrock."""
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 4096,
            "system": SYSTEM_PROMPT,
            "messages": messages,
            "tools": TOOLS,
        }
        response = self.bedrock.invoke_model(
            modelId=MODEL_ID,
            body=json.dumps(body),
        )
        return json.loads(response["body"].read())

    def reset(self):
        """Reset conversation history."""
        self.history = []
