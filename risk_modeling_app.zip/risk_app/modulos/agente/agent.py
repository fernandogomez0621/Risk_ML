"""
Risk Modeling AI Agent — powered by Anthropic API.

Uses tool calling so Claude can query live model results,
EDA statistics, and feature importance on demand.
"""

import json
import os
import requests
import numpy as np
import pandas as pd

ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
MODEL_ID = "claude-sonnet-4-20250514"

SYSTEM_PROMPT = """You are a Senior Data Scientist AI Agent specialized in credit risk modeling.

You have access to the full results of a credit risk origination model built for a technical challenge.
The dataset contains 1,000 company-level observations with 28 features from SERPRO (corporate structure) 
and BACEN (credit bureau), plus a binary target (1=default, 0=good).

PROJECT CONTEXT:
- Bad rate: ~14.6% (854 good, 146 bad) — class imbalance handled via scale_pos_weight / class_weight='balanced'
- 28 original features → 61 total after feature engineering (33 engineered features)
- 6 models trained: LightGBM, XGBoost, CatBoost, Random Forest, Extra Trees, Logistic Regression
- Evaluation: 5-fold stratified outer CV + RandomizedSearchCV (15 iter, 3-fold inner) for HPO
- Primary metric: AUC-ROC (imbalanced classification — accuracy is meaningless here)
- Feature engineering: missing-as-feature, age/maturity, governance, composite credit stress, utilization, domain interactions, log transforms

KEY FINDINGS:
- Best discriminator: serpro__num_owners (ρ=−0.287 Spearman) — sole-owner companies are riskier
- Top engineered feature: fe__is_sole_owner (the best single feature overall)
- 22/28 original features statistically significant (Mann-Whitney U, p<0.05)
- Missing BACEN data = companies without credit products (risk signal, not noise)
- Delinquency flags: has_writeoff_ever χ²=28.42 (p=6.75e-7) — strongest binary predictor
- KS > 0.40 is industry standard for "good" origination model
- Rejecting bottom 2 deciles (20% of applications) catches ~50%+ of defaults

DEPLOYMENT CONTEXT:
- Champion/challenger framework with PSI/CSI drift monitoring
- Target latency <200ms for real-time scoring
- Reject inference needed before production (selection bias from approved-only data)

INSTRUCTIONS:
- Use available tools to answer with REAL numbers from the trained models, not memory
- Be precise and data-driven — cite exact metrics when discussing model performance
- Explain credit risk concepts clearly (KS, Gini, AUC, deciles, PSI, etc.)
- When asked about trade-offs, think like a risk officer: cost of approving a bad >> rejecting a good
- If asked what makes this an AI agent vs conventional model: explain tool use, memory, reasoning, autonomy
- Respond concisely but with enough detail to be actionable
- When relevant, flag limitations (small N, selection bias, no calibration yet)"""


# ─── Tool definitions ────────────────────────────────────────────────────────

TOOLS = [
    {
        "name": "get_model_metrics",
        "description": (
            "Returns performance metrics for one or all trained models. "
            "Use when asked about model performance, best model, AUC, Gini, KS, AP, recall, precision."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "model_name": {
                    "type": "string",
                    "description": (
                        "Model name: 'LightGBM', 'XGBoost', 'CatBoost', 'Random Forest', "
                        "'Extra Trees', 'Logistic Regression', or 'all' for comparison table."
                    ),
                }
            },
            "required": ["model_name"],
        },
    },
    {
        "name": "get_feature_importance",
        "description": (
            "Returns top-N feature importances for a given model. "
            "Use when asked about which features drive the model, variable selection, or risk drivers."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "model_name": {
                    "type": "string",
                    "description": "Model name (same options as get_model_metrics, not 'all').",
                },
                "top_n": {
                    "type": "integer",
                    "description": "Number of top features to return (default 15).",
                },
            },
            "required": ["model_name"],
        },
    },
    {
        "name": "get_eda_statistics",
        "description": (
            "Returns EDA statistics: target distribution, missing rates, Spearman correlations, "
            "Mann-Whitney significance, and chi-squared results for binary flags. "
            "Use when asked about data quality, feature distributions, or variable importance from EDA."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "section": {
                    "type": "string",
                    "description": (
                        "'target' for class distribution, 'missing' for missing rates, "
                        "'correlations' for Spearman with target, 'mann_whitney' for significance tests, "
                        "'chi2' for binary flag tests, or 'all' for everything."
                    ),
                }
            },
            "required": ["section"],
        },
    },
    {
        "name": "get_decile_analysis",
        "description": (
            "Returns the decile table for the best model: count, bads, bad rate, avg probability, "
            "and cumulative bad capture per decile. "
            "Use when asked about risk segmentation, cutoff strategy, or portfolio concentration."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "get_best_model_params",
        "description": (
            "Returns the optimal hyperparameters found by RandomizedSearchCV for a given model. "
            "Use when asked about hyperparameter tuning results or model configuration."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "model_name": {
                    "type": "string",
                    "description": "Model name (not 'all').",
                }
            },
            "required": ["model_name"],
        },
    },
    {
        "name": "get_threshold_analysis",
        "description": (
            "Returns confusion matrix metrics at the KS-optimal threshold for a model: "
            "recall (bad capture), precision, threshold value. "
            "Use when asked about decision threshold, operational cutoff, or rejection strategy."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "model_name": {
                    "type": "string",
                    "description": "Model name.",
                }
            },
            "required": ["model_name"],
        },
    },
]


# ─── Tool execution ──────────────────────────────────────────────────────────

def execute_tool(name: str, params: dict, train_results: dict, eda_results: dict) -> str:
    """Execute a tool call and return result as JSON string."""

    models = train_results.get("models", {})
    best_name = train_results.get("best_model_name", "")

    if name == "get_model_metrics":
        model_name = params.get("model_name", "all")
        if model_name == "all":
            rows = []
            for mn, info in sorted(models.items(), key=lambda x: -x[1]["auc"]):
                rows.append({
                    "Model": mn,
                    "AUC-ROC": round(info["auc"], 4),
                    "Gini": round(info["gini"], 4),
                    "KS": round(info["ks"], 4),
                    "Avg Precision": round(info["ap"], 4),
                    "Recall@KS": round(info["recall_at_ks"], 4),
                    "Precision@KS": round(info["precision_at_ks"], 4),
                    "Best Model": "✓" if mn == best_name else "",
                })
            return json.dumps({"comparison": rows, "best_model": best_name})
        elif model_name in models:
            info = models[model_name]
            return json.dumps({
                "model": model_name,
                "AUC_ROC": round(info["auc"], 4),
                "Gini": round(info["gini"], 4),
                "KS": round(info["ks"], 4),
                "Avg_Precision": round(info["ap"], 4),
                "Recall_at_KS_threshold": round(info["recall_at_ks"], 4),
                "Precision_at_KS_threshold": round(info["precision_at_ks"], 4),
                "KS_threshold": round(info["ks_threshold"], 4),
                "confusion_matrix": info["confusion_matrix"],
            })
        else:
            return json.dumps({"error": f"Model '{model_name}' not found. Available: {list(models.keys())}"})

    elif name == "get_feature_importance":
        model_name = params.get("model_name", best_name)
        top_n = params.get("top_n", 15)
        if model_name not in models:
            return json.dumps({"error": f"Model '{model_name}' not found."})
        fi = models[model_name].get("feature_importance")
        if not fi:
            return json.dumps({"note": f"{model_name} does not expose feature importances."})
        sorted_fi = sorted(fi.items(), key=lambda x: x[1], reverse=True)[:top_n]
        return json.dumps({
            "model": model_name,
            "top_features": [
                {"feature": k, "importance": round(v, 6), "engineered": k.startswith("fe__")}
                for k, v in sorted_fi
            ],
            "engineered_in_top": sum(1 for k, _ in sorted_fi if k.startswith("fe__")),
        })

    elif name == "get_eda_statistics":
        section = params.get("section", "all")
        result = {}
        if section in ("all", "target"):
            result["target_distribution"] = eda_results.get("target_dist", {})
            result["bad_rate"] = round(eda_results.get("bad_rate", 0), 4)
            result["n_observations"] = eda_results.get("n", 0)
        if section in ("all", "missing"):
            mdf = eda_results.get("missing_df", pd.DataFrame())
            result["missing_features"] = mdf[mdf["missing_count"] > 0].head(15).to_dict(orient="records")
        if section in ("all", "correlations"):
            sc = eda_results.get("spearman_corr", pd.Series())
            top_pos = sc.sort_values(ascending=False).head(10)
            top_neg = sc.sort_values().head(5)
            result["top_positive_correlations"] = top_pos.round(4).to_dict()
            result["top_negative_correlations"] = top_neg.round(4).to_dict()
        if section in ("all", "mann_whitney"):
            mw = eda_results.get("mw_df", pd.DataFrame())
            result["significant_features"] = int(mw["significant"].sum()) if len(mw) else 0
            result["total_tested"] = len(mw)
            result["top_10_discriminating"] = mw.head(10)[
                ["variable", "p_value", "median_good", "median_bad"]
            ].to_dict(orient="records") if len(mw) else []
        if section in ("all", "chi2"):
            chi2 = eda_results.get("chi2_df", pd.DataFrame())
            result["chi2_tests"] = chi2.head(10).to_dict(orient="records") if len(chi2) else []
        return json.dumps(result, default=str)

    elif name == "get_decile_analysis":
        decile_df = train_results.get("decile_df", pd.DataFrame())
        best = train_results.get("best_model_name", "")
        return json.dumps({
            "model": best,
            "decile_table": decile_df.to_dict(orient="records") if len(decile_df) else [],
            "note": "Decile 1=lowest risk (highest score), Decile 10=highest risk",
        })

    elif name == "get_best_model_params":
        model_name = params.get("model_name", best_name)
        if model_name not in models:
            return json.dumps({"error": f"Model '{model_name}' not found."})
        return json.dumps({
            "model": model_name,
            "best_params": models[model_name].get("best_params", {}),
        })

    elif name == "get_threshold_analysis":
        model_name = params.get("model_name", best_name)
        if model_name not in models:
            return json.dumps({"error": f"Model '{model_name}' not found."})
        info = models[model_name]
        cm = info["confusion_matrix"]
        tn, fp, fn, tp = np.array(cm).ravel()
        return json.dumps({
            "model": model_name,
            "ks_threshold": round(info["ks_threshold"], 4),
            "recall_bads": round(info["recall_at_ks"], 4),
            "precision_bads": round(info["precision_at_ks"], 4),
            "true_negatives": int(tn),
            "false_positives": int(fp),
            "false_negatives": int(fn),
            "true_positives": int(tp),
            "interpretation": (
                f"At threshold {info['ks_threshold']:.3f}: "
                f"model captures {info['recall_at_ks']*100:.1f}% of bad companies. "
                f"For every rejection, {1/max(info['precision_at_ks'], 0.001):.1f} are actual defaults."
            ),
        })

    return json.dumps({"error": f"Unknown tool: {name}"})


# ─── Agent class ─────────────────────────────────────────────────────────────

class RiskAgent:
    def __init__(self, api_key: str, train_results: dict, eda_results: dict):
        self.api_key = api_key
        self.train_results = train_results
        self.eda_results = eda_results
        self.history = []

    def query(self, user_message: str) -> str:
        self.history.append({"role": "user", "content": user_message})
        response = self._call_api(self.history)

        # Agentic loop — handle tool calls
        while response.get("stop_reason") == "tool_use":
            assistant_content = response["content"]
            self.history.append({"role": "assistant", "content": assistant_content})

            tool_results = []
            for block in assistant_content:
                if block.get("type") == "tool_use":
                    result = execute_tool(
                        block["name"],
                        block["input"],
                        self.train_results,
                        self.eda_results,
                    )
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": block["id"],
                        "content": result,
                    })

            self.history.append({"role": "user", "content": tool_results})
            response = self._call_api(self.history)

        # Extract text
        text = ""
        for block in response.get("content", []):
            if block.get("type") == "text":
                text += block["text"]

        self.history.append({"role": "assistant", "content": response.get("content", [])})
        return text

    def _call_api(self, messages: list) -> dict:
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        body = {
            "model": MODEL_ID,
            "max_tokens": 2048,
            "system": SYSTEM_PROMPT,
            "messages": messages,
            "tools": TOOLS,
        }
        resp = requests.post(ANTHROPIC_API_URL, headers=headers, json=body, timeout=60)
        resp.raise_for_status()
        return resp.json()

    def reset(self):
        self.history = []
