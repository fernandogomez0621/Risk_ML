"""
Data loading, feature engineering, and model training pipeline.
All computation runs locally — no S3 required.
Results are cached in session_state to avoid recomputation.
"""

import pandas as pd
import numpy as np
import json
import pickle
import os
import streamlit as st
from scipy import stats
from sklearn.model_selection import StratifiedKFold, cross_val_predict, RandomizedSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    roc_auc_score, roc_curve, precision_recall_curve,
    average_precision_score, classification_report,
    confusion_matrix, f1_score, precision_score, recall_score
)
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
import warnings

warnings.filterwarnings("ignore")
np.random.seed(42)

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "data.csv")
MODEL_CACHE = os.path.join(os.path.dirname(__file__), "..", "..", "model_cache.pkl")


# ─── Raw data ───────────────────────────────────────────────────────────────

@st.cache_data(show_spinner=False)
def load_raw():
    df = pd.read_csv(DATA_PATH)
    return df


# ─── Feature engineering ────────────────────────────────────────────────────

@st.cache_data(show_spinner=False)
def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    fe = df.copy()

    # --- Missing as feature ---
    fe["fe__has_no_bacen_data"] = fe["bacen__has_bacen_last_1m"].apply(
        lambda x: 1 if x == 0 else 0
    )
    fe["fe__missing_cc_data"] = fe["bacen__utilization_cc_last_1m"].isnull().astype(int)
    fe["fe__missing_bacen_ratios"] = fe["bacen__utilization_last_1m"].isnull().astype(int)

    # --- Age & maturity ---
    fe["fe__company_age_years"] = fe["serpro__company_age_months"] / 12
    fe["fe__is_young_company"] = (fe["serpro__company_age_months"] < 24).astype(int)
    fe["fe__is_very_young_company"] = (fe["serpro__company_age_months"] < 6).astype(int)
    fe["fe__account_age_range"] = (
        fe["bacen__max_account_age_months"] - fe["bacen__min_account_age_months"]
    )
    fe["fe__company_vs_max_account_age"] = (
        fe["serpro__company_age_months"] - fe["bacen__max_account_age_months"]
    )
    fe["fe__account_to_company_age_ratio"] = np.where(
        fe["serpro__company_age_months"] > 0,
        fe["bacen__max_account_age_months"] / fe["serpro__company_age_months"],
        0,
    )

    # --- Corporate governance ---
    fe["fe__is_sole_owner"] = (fe["serpro__num_owners"] == 1).astype(int)
    fe["fe__owners_added_ratio"] = np.where(
        fe["serpro__num_owners"] > 0,
        fe["serpro__num_owners_added_last_12m"] / fe["serpro__num_owners"],
        0,
    )
    fe["fe__all_owners_are_new"] = (
        (fe["serpro__num_owners_added_last_12m"] == fe["serpro__num_owners"])
        & (fe["serpro__num_owners"] > 0)
    ).astype(int)
    fe["fe__owner_tenure_vs_company_age"] = np.where(
        fe["serpro__company_age_months"] > 0,
        fe["serpro__avg_owner_tenure_months"] / fe["serpro__company_age_months"],
        0,
    )
    fe["fe__has_non_executive_owners"] = (
        fe["serpro__num_non_executive_owners"] > 0
    ).astype(int)

    # --- Composite credit stress ---
    fe["fe__any_delinquency"] = (
        (fe["bacen__has_over30_last_1m"] == 1) | (fe["bacen__has_over60_last_1m"] == 1)
    ).astype(int)
    fe["fe__severe_delinquency"] = (
        (fe["bacen__has_over60_last_1m"] == 1)
        | (fe["bacen__has_writeoff_last_12m"] == 1)
    ).astype(int)
    fe["fe__delinquency_score"] = (
        fe["bacen__has_over30_last_1m"].fillna(0) * 1
        + fe["bacen__has_over60_last_1m"].fillna(0) * 2
        + fe["bacen__has_writeoff_last_12m"].fillna(0) * 3
        + fe["bacen__has_writeoff_last_48m"].fillna(0) * 2
        + fe["bacen__has_writeoff_ever"].fillna(0) * 1
    )
    fe["fe__writeoff_escalation"] = (
        fe["bacen__has_writeoff_last_12m"].fillna(0) * 3
        + fe["bacen__has_writeoff_last_48m"].fillna(0) * 2
        + fe["bacen__has_writeoff_ever"].fillna(0) * 1
    )

    # --- Utilization behavior ---
    fe["fe__high_utilization"] = (fe["bacen__utilization_last_1m"] > 0.8).astype(int)
    fe["fe__very_high_utilization"] = (
        fe["bacen__utilization_last_1m"] > 0.95
    ).astype(int)
    fe["fe__cc_utilization_excess"] = np.where(
        fe["bacen__utilization_last_1m"] > 0,
        fe["bacen__utilization_cc_last_1m"]
        / (fe["bacen__utilization_last_1m"] + 1e-6),
        0,
    )
    fe["fe__overdue_intensity"] = (
        fe["bacen__overdue_ratio_last_1m"].fillna(0)
        + fe["bacen__over30_ratio_last_1m"].fillna(0)
        + fe["bacen__over60_ratio_last_1m"].fillna(0)
    )
    fe["fe__overdue_intensity_cc"] = (
        fe["bacen__overdue_ratio_cc_last_1m"].fillna(0)
        + fe["bacen__over30_ratio_cc_last_1m"].fillna(0)
        + fe["bacen__over60_ratio_cc_last_1m"].fillna(0)
    )

    # --- Domain interactions ---
    fe["fe__young_x_delinquency"] = fe["fe__is_young_company"] * fe["fe__any_delinquency"]
    fe["fe__sole_owner_x_young"] = fe["fe__is_sole_owner"] * fe["fe__is_young_company"]
    fe["fe__high_util_x_delinquency"] = (
        fe["fe__high_utilization"] * fe["fe__any_delinquency"]
    )
    fe["fe__no_bacen_x_young"] = (
        fe["fe__has_no_bacen_data"] * fe["fe__is_young_company"]
    )

    # --- Log transforms ---
    for col in [
        "serpro__company_age_months",
        "bacen__max_account_age_months",
        "bacen__min_account_age_months",
        "serpro__avg_owner_tenure_months",
    ]:
        fe[f"fe__log_{col}"] = np.log1p(fe[col].fillna(0))

    return fe


# ─── EDA helpers ────────────────────────────────────────────────────────────

@st.cache_data(show_spinner=False)
def compute_eda(df: pd.DataFrame) -> dict:
    original_features = [c for c in df.columns if c not in ["id", "target"]]

    # Descriptive stats
    desc = df[original_features].describe().T
    desc["missing_pct"] = df[original_features].isnull().mean() * 100
    desc["bad_rate_corr"] = df[original_features].corrwith(
        df["target"], method="spearman"
    )

    # Target distribution
    target_dist = df["target"].value_counts().to_dict()

    # Missing info
    missing = (
        df[original_features].isnull().sum().sort_values(ascending=False)
    )
    missing_df = pd.DataFrame(
        {"feature": missing.index, "missing_count": missing.values,
         "missing_pct": missing.values / len(df) * 100}
    )

    # Mann-Whitney
    mw_results = []
    for f in original_features:
        good = df.loc[df["target"] == 0, f].dropna()
        bad = df.loc[df["target"] == 1, f].dropna()
        if len(good) > 5 and len(bad) > 5:
            stat, pval = stats.mannwhitneyu(good, bad, alternative="two-sided")
            mw_results.append(
                {
                    "variable": f,
                    "U_statistic": round(stat, 1),
                    "p_value": pval,
                    "median_good": round(good.median(), 4),
                    "median_bad": round(bad.median(), 4),
                    "significant": pval < 0.05,
                }
            )
    mw_df = pd.DataFrame(mw_results).sort_values("p_value")

    # Spearman correlations with target
    spearman_corr = (
        df[original_features]
        .corrwith(df["target"], method="spearman")
        .sort_values()
    )

    # Full correlation matrix
    corr_matrix = df[original_features].corr(method="spearman")

    # Chi-squared on binary flags
    binary_vars = [
        c for c in original_features
        if df[c].dropna().isin([0, 1]).all() and df[c].nunique() <= 3
    ]
    chi2_results = []
    for v in binary_vars:
        ct = pd.crosstab(df[v].fillna(-1), df["target"])
        chi2, p, dof, _ = stats.chi2_contingency(ct)
        chi2_results.append(
            {"variable": v, "chi2": round(chi2, 2), "p_value": p, "dof": dof}
        )
    chi2_df = pd.DataFrame(chi2_results).sort_values("chi2", ascending=False)

    return {
        "original_features": original_features,
        "desc": desc,
        "target_dist": target_dist,
        "bad_rate": df["target"].mean(),
        "n": len(df),
        "missing_df": missing_df,
        "mw_df": mw_df,
        "spearman_corr": spearman_corr,
        "corr_matrix": corr_matrix,
        "chi2_df": chi2_df,
    }


# ─── Model training ─────────────────────────────────────────────────────────

@st.cache_data(show_spinner=False)
def train_models(fe_df: pd.DataFrame) -> dict:
    """Train all 6 models with 5-fold CV + HPO (RandomizedSearchCV 15 iter, 3-fold inner)."""

    feature_cols = [c for c in fe_df.columns if c not in ["id", "target"]]
    X = fe_df[feature_cols]
    y = fe_df["target"]

    bad_rate = y.mean()
    scale_pos = (1 - bad_rate) / bad_rate  # for tree models

    cv_outer = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_inner = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)

    imputer = SimpleImputer(strategy="median")
    scaler = StandardScaler()

    # --- Model configs ---
    model_configs = {
        "LightGBM": {
            "model": lgb.LGBMClassifier(
                random_state=42, scale_pos_weight=scale_pos, verbose=-1
            ),
            "params": {
                "n_estimators": [50, 100, 200],
                "learning_rate": [0.03, 0.05, 0.1],
                "max_depth": [3, 4, 5],
                "num_leaves": [15, 31, 63],
                "min_child_samples": [20, 50],
                "subsample": [0.7, 0.8, 1.0],
                "colsample_bytree": [0.7, 0.8, 1.0],
                "reg_alpha": [0, 0.1, 0.5],
                "reg_lambda": [0, 0.1, 0.5],
            },
            "needs_impute": True,
            "needs_scale": False,
        },
        "XGBoost": {
            "model": xgb.XGBClassifier(
                random_state=42, scale_pos_weight=scale_pos,
                eval_metric="logloss", verbosity=0
            ),
            "params": {
                "n_estimators": [50, 100, 200],
                "learning_rate": [0.03, 0.05, 0.1],
                "max_depth": [3, 5, 6],
                "min_child_weight": [1, 3, 5],
                "subsample": [0.7, 0.8, 1.0],
                "colsample_bytree": [0.6, 0.7, 0.8],
                "reg_alpha": [0, 0.1, 0.5],
                "reg_lambda": [0.1, 1.0],
                "gamma": [0, 0.5, 1.0],
            },
            "needs_impute": True,
            "needs_scale": False,
        },
        "CatBoost": {
            "model": CatBoostClassifier(
                random_state=42, scale_pos_weight=scale_pos,
                verbose=0, allow_writing_files=False
            ),
            "params": {
                "iterations": [50, 100, 200],
                "learning_rate": [0.03, 0.05, 0.1],
                "depth": [4, 5, 6],
                "l2_leaf_reg": [1, 3, 5],
                "min_data_in_leaf": [5, 10, 20],
                "bagging_temperature": [0, 0.5, 1.0],
            },
            "needs_impute": True,
            "needs_scale": False,
        },
        "Random Forest": {
            "model": RandomForestClassifier(
                random_state=42, class_weight="balanced"
            ),
            "params": {
                "n_estimators": [100, 200],
                "max_depth": [4, 6, 8, None],
                "min_samples_leaf": [5, 10, 20],
                "min_samples_split": [5, 10],
                "max_features": ["sqrt", 0.5],
            },
            "needs_impute": True,
            "needs_scale": False,
        },
        "Extra Trees": {
            "model": ExtraTreesClassifier(
                random_state=42, class_weight="balanced"
            ),
            "params": {
                "n_estimators": [100, 200],
                "max_depth": [4, 6, 8, None],
                "min_samples_leaf": [5, 10, 20],
                "min_samples_split": [5, 10],
                "max_features": ["sqrt", 0.5],
            },
            "needs_impute": True,
            "needs_scale": False,
        },
        "Logistic Regression": {
            "model": Pipeline([
                ("imputer", SimpleImputer(strategy="median")),
                ("scaler", StandardScaler()),
                ("lr", LogisticRegression(
                    class_weight="balanced", max_iter=1000, random_state=42
                )),
            ]),
            "params": {
                "lr__C": [0.01, 0.1, 1.0, 10.0],
                "lr__solver": ["lbfgs", "liblinear"],
            },
            "needs_impute": False,
            "needs_scale": False,
        },
    }

    results = {}

    for name, cfg in model_configs.items():
        model_base = cfg["model"]
        param_grid = cfg["params"]
        needs_impute = cfg["needs_impute"]
        needs_scale = cfg["needs_scale"]

        # Prepare data
        if needs_impute:
            X_proc = pd.DataFrame(
                imputer.fit_transform(X), columns=feature_cols
            )
        else:
            X_proc = X.copy()

        if needs_scale:
            X_proc = pd.DataFrame(
                scaler.fit_transform(X_proc), columns=feature_cols
            )

        # HPO
        search = RandomizedSearchCV(
            model_base,
            param_grid,
            n_iter=15,
            scoring="roc_auc",
            cv=cv_inner,
            random_state=42,
            n_jobs=-1,
        )
        search.fit(X_proc, y)
        best_model = search.best_estimator_

        # Outer CV evaluation
        oof_probs = cross_val_predict(
            best_model, X_proc, y, cv=cv_outer, method="predict_proba"
        )[:, 1]

        auc = roc_auc_score(y, oof_probs)
        gini = 2 * auc - 1
        ap = average_precision_score(y, oof_probs)

        # KS
        fpr, tpr, thresholds = roc_curve(y, oof_probs)
        ks = np.max(tpr - fpr)
        ks_threshold = thresholds[np.argmax(tpr - fpr)]

        # At KS threshold
        preds_ks = (oof_probs >= ks_threshold).astype(int)
        cm = confusion_matrix(y, preds_ks)
        recall_val = recall_score(y, preds_ks)
        precision_val = precision_score(y, preds_ks, zero_division=0)

        # Feature importance (if available)
        fi = None
        if hasattr(best_model, "feature_importances_"):
            fi = dict(zip(feature_cols, best_model.feature_importances_))
        elif hasattr(best_model, "named_steps"):
            lr_step = best_model.named_steps.get("lr")
            if hasattr(lr_step, "coef_"):
                fi = dict(zip(feature_cols, np.abs(lr_step.coef_[0])))

        # Fit final model on all data for saving
        best_model.fit(X_proc, y)

        results[name] = {
            "auc": auc,
            "gini": gini,
            "ks": ks,
            "ks_threshold": ks_threshold,
            "ap": ap,
            "recall_at_ks": recall_val,
            "precision_at_ks": precision_val,
            "confusion_matrix": cm.tolist(),
            "best_params": search.best_params_,
            "oof_probs": oof_probs.tolist(),
            "feature_importance": fi,
            "fpr": fpr.tolist(),
            "tpr": tpr.tolist(),
            "thresholds": thresholds.tolist(),
            "model": best_model,
            "X_proc": X_proc,
            "feature_cols": feature_cols,
        }

    # Best model by AUC
    best_name = max(results, key=lambda k: results[k]["auc"])

    # Decile analysis on best model
    best = results[best_name]
    decile_df = _decile_analysis(np.array(best["oof_probs"]), y.values)

    return {
        "models": results,
        "best_model_name": best_name,
        "feature_cols": feature_cols,
        "decile_df": decile_df,
        "X": X,
        "y": y,
        "imputer": imputer,
    }


def _decile_analysis(probs, y_true):
    df = pd.DataFrame({"prob": probs, "target": y_true})
    df["decile"] = pd.qcut(df["prob"], 10, labels=False, duplicates="drop")
    df["decile"] = 10 - df["decile"]  # 10 = highest risk

    summary = []
    cumulative_bads = 0
    total_bads = y_true.sum()

    for d in range(1, 11):
        group = df[df["decile"] == d]
        n = len(group)
        bads = group["target"].sum()
        cumulative_bads += bads
        summary.append(
            {
                "Decile": d,
                "Count": n,
                "Bads": int(bads),
                "Bad Rate": f"{bads/n*100:.1f}%" if n > 0 else "N/A",
                "Avg Prob": f"{group['prob'].mean():.3f}",
                "Cum Bad %": f"{cumulative_bads/total_bads*100:.1f}%",
            }
        )
    return pd.DataFrame(summary)


# ─── Single prediction ───────────────────────────────────────────────────────

def predict_single(train_results: dict, model_name: str, input_data: dict) -> dict:
    """Score a single observation using the trained pipeline."""
    model_info = train_results["models"][model_name]
    feature_cols = model_info["feature_cols"]
    model = model_info["model"]
    X_proc = model_info["X_proc"]

    # Build a row — fill missing engineered features with 0
    row = {}
    for col in feature_cols:
        row[col] = input_data.get(col, 0)

    row_df = pd.DataFrame([row])[feature_cols]

    # Apply same imputation as training (column means from X_proc)
    for col in feature_cols:
        if pd.isna(row_df[col].values[0]):
            row_df[col] = X_proc[col].mean()

    prob = model.predict_proba(row_df)[0, 1]
    pred = int(prob >= model_info["ks_threshold"])
    risk_decile = int(np.ceil(prob * 10))

    return {
        "probability": float(prob),
        "prediction": pred,
        "risk_decile": min(risk_decile, 10),
        "ks_threshold": float(model_info["ks_threshold"]),
        "recommendation": "REJECT" if pred == 1 else "APPROVE",
    }
