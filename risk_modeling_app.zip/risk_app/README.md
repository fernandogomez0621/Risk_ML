# 🏦 Credit Risk Origination — Risk Modeling Challenge

End-to-end credit risk classification app built with Streamlit.  
Runs **entirely on the EC2 instance** — no S3, no external data source needed.

---

## 📁 Structure

```
risk_app/
├── app.py                          # Main Streamlit entrypoint
├── data.csv                        # Dataset (1,000 companies, 30 cols)
├── requirements.txt
└── modulos/
    ├── datos/
    │   └── loader.py               # Data loading, FE, EDA, model training
    ├── visualizaciones/
    │   ├── eda_plots.py            # EDA Plotly charts
    │   └── model_plots.py         # Model evaluation charts
    └── agente/
        └── agent.py               # AI Agent (Anthropic API + tool calling)
```

---

## 🚀 Deploy on EC2

### 1. Clone repo & install dependencies

```bash
git clone https://github.com/YOUR_USERNAME/risk-modeling-app.git
cd risk-modeling-app
pip install -r requirements.txt
```

### 2. Run the app

```bash
streamlit run app.py --server.port 8501 --server.address 0.0.0.0
```

Then visit `http://YOUR_EC2_PUBLIC_IP:8501`

### 3. Run in background (tmux)

```bash
tmux new -s streamlit
streamlit run app.py --server.port 8501 --server.address 0.0.0.0
# Ctrl+B then D to detach
```

### 4. EC2 Security Group

Make sure port **8501** (TCP) is open in your EC2 Security Group inbound rules.

---

## 🤖 AI Agent

The AI Agent page uses the **Anthropic API** directly (no AWS Bedrock).

Enter your Anthropic API key in the sidebar at runtime.  
The key is never stored — it lives only in the Streamlit session.

Get your key at: https://console.anthropic.com

---

## 📊 App Pages

| Page | Description |
|---|---|
| 🏠 Overview | Project summary, key findings, deployment architecture |
| 📊 EDA | Target distribution, missing values, correlations, statistical tests, FE overview |
| 🤖 Models | ROC/PR curves, KS, confusion matrix, feature importance, decile analysis, HPO results |
| 🎯 Prediction | Real-time scoring: enter company features → get probability + decile + APPROVE/REJECT |
| 💬 AI Agent | Conversational agent powered by Claude (tool-augmented) |

---

## ⚙️ Technical Notes

- **Model training** runs on first load and is cached (`@st.cache_resource`)
- **EDA** is cached per data hash (`@st.cache_data`)
- Typical training time: **2–4 minutes** on first run (6 models × HPO)
- After first run, Streamlit hot-reloads use the cache — instant

---

## 🔧 Environment Variables (optional)

You can set the API key via env var instead of the sidebar:

```bash
export ANTHROPIC_API_KEY=sk-ant-...
streamlit run app.py
```

Then modify `app.py` to read `os.environ.get("ANTHROPIC_API_KEY")` as default.
